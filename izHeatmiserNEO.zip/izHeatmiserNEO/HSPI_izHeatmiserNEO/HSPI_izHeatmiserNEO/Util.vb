﻿Imports HomeSeerAPI
Imports Scheduler
Imports System.Reflection
Imports System.Text


Imports System.IO
Imports System.Runtime.Serialization
Imports System.Runtime.Serialization.Formatters


Module Util
   
    ' interface status
    ' for InterfaceStatus function call
    Public Const ERR_NONE = 0
    Public Const ERR_SEND = 1
    Public Const ERR_INIT = 2

    Public hs As HomeSeerAPI.IHSApplication
    Public callback As HomeSeerAPI.IAppCallbackAPI
    Public Const IFACE_NAME As String = "izHeatmiserNEO"
    Public Instance As String = "" ' set when SupportMultipleInstances is TRUE
    Public gEXEPath As String = ""
    Public gGlobalTempScaleF As Boolean = True

    Public colTrigs_Sync As System.Collections.SortedList
    Public colTrigs As System.Collections.SortedList
    Public colActs_Sync As System.Collections.SortedList
    Public colActs As System.Collections.SortedList

    Private Demo_ARE As Threading.AutoResetEvent
    Private Demo_Thread As Threading.Thread

    Public Function StringIsNullOrEmpty(ByRef s As String) As Boolean
        If String.IsNullOrEmpty(s) Then Return True
        Return String.IsNullOrEmpty(s.Trim)
    End Function

    Enum LogType
        LOG_TYPE_INFO = 0
        LOG_TYPE_ERROR = 1
        LOG_TYPE_WARNING = 2
    End Enum

    Public Sub Log(ByVal msg As String, ByVal logType As LogType)
        Try
            If msg Is Nothing Then msg = ""
            If Not [Enum].IsDefined(GetType(LogType), logType) Then
                logType = Util.LogType.LOG_TYPE_ERROR
            End If
            Console.WriteLine(msg)
            Select Case logType
                Case logType.LOG_TYPE_ERROR
                    hs.WriteLog(IFACE_NAME & " Error", msg)
                Case logType.LOG_TYPE_WARNING
                    hs.WriteLog(IFACE_NAME & " Warning", msg)
                Case logType.LOG_TYPE_INFO
                    hs.WriteLog(IFACE_NAME, msg)
            End Select
        Catch ex As Exception
            Console.WriteLine("Exception in LOG of " & IFACE_NAME & ": " & ex.Message)
        End Try

    End Sub

    Friend Enum eTriggerType
        OneTon = 1
        TwoVolts = 2
        Unknown = 0
    End Enum
    Friend Enum eActionType
        Unknown = 0
        Weight = 1
        Voltage = 2
    End Enum

    Friend Structure strTrigger
        Public WhichTrigger As eTriggerType
        Public TrigObj As Object
        Public Result As Boolean
    End Structure
    Friend Structure strAction
        Public WhichAction As eActionType
        Public ActObj As Object
        Public Result As Boolean
    End Structure

    Friend Function TriggerFromData(ByRef Data As Byte()) As strTrigger
        Dim ST As New strTrigger
        ST.WhichTrigger = eTriggerType.Unknown
        ST.Result = False
        If Data Is Nothing Then Return ST
        If Data.Length < 1 Then Return ST

        Dim bRes As Boolean = False
        Dim Trig1 As New MyTrigger1Ton
        Dim Trig2 As New MyTrigger2Shoe
        Try
            bRes = DeSerializeObject(Data, Trig1)
        Catch ex As Exception
            bRes = False
        End Try
        If bRes And Trig1 IsNot Nothing Then
            ST.WhichTrigger = eTriggerType.OneTon
            ST.TrigObj = Trig1
            ST.Result = True
            Return ST
        End If
        Try
            bRes = DeSerializeObject(Data, Trig2)
        Catch ex As Exception
            bRes = False
        End Try
        If bRes And Trig2 IsNot Nothing Then
            ST.WhichTrigger = eTriggerType.TwoVolts
            ST.TrigObj = Trig2
            ST.Result = True
            Return ST
        End If
        ST.WhichTrigger = eTriggerType.Unknown
        ST.TrigObj = Nothing
        ST.Result = False
        Return ST
    End Function

    Friend Function ActionFromData(ByRef Data As Byte()) As strAction
        Dim ST As New strAction
        ST.WhichAction = eActionType.Unknown
        ST.Result = False
        If Data Is Nothing Then Return ST
        If Data.Length < 1 Then Return ST

        Dim bRes As Boolean = False
        Dim Act1 As New MyAction1EvenTon
        Dim Act2 As New MyAction2Euro
        Try
            bRes = DeSerializeObject(Data, Act1)
        Catch ex As Exception
            bRes = False
        End Try
        If bRes And Act1 IsNot Nothing Then
            ST.WhichAction = eActionType.Weight
            ST.ActObj = Act1
            ST.Result = True
            Return ST
        End If
        Try
            bRes = DeSerializeObject(Data, Act2)
        Catch ex As Exception
            bRes = False
        End Try
        If bRes And Act2 IsNot Nothing Then
            ST.WhichAction = eActionType.Voltage
            ST.ActObj = Act2
            ST.Result = True
            Return ST
        End If
        ST.WhichAction = eActionType.Unknown
        ST.ActObj = Nothing
        ST.Result = False
        Return ST
    End Function

    Sub Add_Update_Trigger(ByVal Trig As Object)
        If Trig Is Nothing Then Exit Sub
        Dim sKey As String = ""
        If TypeOf Trig Is MyTrigger1Ton Then
            Dim Trig1 As MyTrigger1Ton = Nothing
            Try
                Trig1 = CType(Trig, MyTrigger1Ton)
            Catch ex As Exception
                Trig1 = Nothing
            End Try
            If Trig1 IsNot Nothing Then
                If Trig1.TriggerUID < 1 Then Exit Sub
                sKey = "K" & Trig1.TriggerUID.ToString
                If colTrigs.ContainsKey(sKey) Then
                    SyncLock colTrigs.SyncRoot
                        colTrigs.Remove(sKey)
                    End SyncLock
                End If
                colTrigs.Add(sKey, Trig1)
            End If
        ElseIf TypeOf Trig Is MyTrigger2Shoe Then
            Dim Trig2 As MyTrigger2Shoe = Nothing
            Try
                Trig2 = CType(Trig, MyTrigger2Shoe)
            Catch ex As Exception
                Trig2 = Nothing
            End Try
            If Trig2 IsNot Nothing Then
                If Trig2.TriggerUID < 1 Then Exit Sub
                sKey = "K" & Trig2.TriggerUID.ToString
                If colTrigs.ContainsKey(sKey) Then
                    SyncLock colTrigs.SyncRoot
                        colTrigs.Remove(sKey)
                    End SyncLock
                End If
                colTrigs.Add(sKey, Trig2)
            End If
        End If
    End Sub

    Sub Add_Update_Action(ByVal Act As Object)
        If Act Is Nothing Then Exit Sub
        Dim sKey As String = ""
        If TypeOf Act Is MyAction1EvenTon Then
            Dim Act1 As MyAction1EvenTon = Nothing
            Try
                Act1 = CType(Act, MyAction1EvenTon)
            Catch ex As Exception
                Act1 = Nothing
            End Try
            If Act1 IsNot Nothing Then
                If Act1.ActionUID < 1 Then Exit Sub
                sKey = "K" & Act1.ActionUID.ToString
                If colActs.ContainsKey(sKey) Then
                    SyncLock colActs.SyncRoot
                        colActs.Remove(sKey)
                    End SyncLock
                End If
                colActs.Add(sKey, Act1)
            End If
        ElseIf TypeOf Act Is MyAction2Euro Then
            Dim Act2 As MyAction2Euro = Nothing
            Try
                Act2 = CType(Act, MyAction2Euro)
            Catch ex As Exception
                Act2 = Nothing
            End Try
            If Act2 IsNot Nothing Then
                If Act2.ActionUID < 1 Then Exit Sub
                sKey = "K" & Act2.ActionUID.ToString
                If colActs.ContainsKey(sKey) Then
                    SyncLock colActs.SyncRoot
                        colActs.Remove(sKey)
                    End SyncLock
                End If
                colActs.Add(sKey, Act2)
            End If
        End If
    End Sub

    Public MyDevice As Integer = -1
    Public MyTempDevice As Integer = -1

    Private Sub Default_VG_Pairs_AddUpdateUtil(ByVal dvRef As Integer, ByRef Pair As VGPair)
        If Pair Is Nothing Then Exit Sub
        If dvRef < 1 Then Exit Sub
        If Not hs.DeviceExistsRef(dvRef) Then Exit Sub

        Dim Existing As VGPair = Nothing

        ' The purpose of this procedure is to add the protected, default VS/VG pairs WITHOUT overwriting any user added
        '   pairs unless absolutely necessary (because they conflict).

        Try
            Existing = hs.DeviceVGP_Get(dvRef, Pair.Value) 'VGPairs.GetPairByValue(Pair.Value)

            If Existing IsNot Nothing Then
                hs.DeviceVGP_Clear(dvRef, Pair.Value)
                hs.DeviceVGP_AddPair(dvRef, Pair)
            Else
                ' There is not a pair existing, so just add it.
                hs.DeviceVGP_AddPair(dvRef, Pair)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Default_VS_Pairs_AddUpdateUtil(ByVal dvRef As Integer, ByRef Pair As VSPair)
        If Pair Is Nothing Then Exit Sub
        If dvRef < 1 Then Exit Sub
        If Not hs.DeviceExistsRef(dvRef) Then Exit Sub

        Dim Existing As VSPair = Nothing

        ' The purpose of this procedure is to add the protected, default VS/VG pairs WITHOUT overwriting any user added
        '   pairs unless absolutely necessary (because they conflict).

        Try
            Existing = hs.DeviceVSP_Get(dvRef, Pair.Value, Pair.ControlStatus) 'VSPairs.GetPairByValue(Pair.Value, Pair.ControlStatus)

            If Existing IsNot Nothing Then

                ' This is unprotected, so it is a user's value/status pair.
                If Existing.ControlStatus = HomeSeerAPI.ePairStatusControl.Both And Pair.ControlStatus <> HomeSeerAPI.ePairStatusControl.Both Then
                    ' The existing one is for BOTH, so try changing it to the opposite of what we are adding and then add it.
                    If Pair.ControlStatus = HomeSeerAPI.ePairStatusControl.Status Then
                        If Not hs.DeviceVSP_ChangePair(dvRef, Existing, HomeSeerAPI.ePairStatusControl.Control) Then
                            hs.DeviceVSP_ClearBoth(dvRef, Pair.Value)
                            hs.DeviceVSP_AddPair(dvRef, Pair)
                        Else
                            hs.DeviceVSP_AddPair(dvRef, Pair)
                        End If
                    Else
                        If Not hs.DeviceVSP_ChangePair(dvRef, Existing, HomeSeerAPI.ePairStatusControl.Status) Then
                            hs.DeviceVSP_ClearBoth(dvRef, Pair.Value)
                            hs.DeviceVSP_AddPair(dvRef, Pair)
                        Else
                            hs.DeviceVSP_AddPair(dvRef, Pair)
                        End If
                    End If
                ElseIf Existing.ControlStatus = HomeSeerAPI.ePairStatusControl.Control Then
                    ' There is an existing one that is STATUS or CONTROL - remove it if ours is protected.
                    hs.DeviceVSP_ClearControl(dvRef, Pair.Value)
                    hs.DeviceVSP_AddPair(dvRef, Pair)

                ElseIf Existing.ControlStatus = HomeSeerAPI.ePairStatusControl.Status Then
                    ' There is an existing one that is STATUS or CONTROL - remove it if ours is protected.
                    hs.DeviceVSP_ClearStatus(dvRef, Pair.Value)
                    hs.DeviceVSP_AddPair(dvRef, Pair)

                End If

            Else
                ' There is not a pair existing, so just add it.
                hs.DeviceVSP_AddPair(dvRef, Pair)

            End If

        Catch ex As Exception

        End Try
    End Sub

    Friend Function TriggerFromInfo(ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As strTrigger
        Dim sKey As String = ""
        sKey = "K" & TrigInfo.UID.ToString
        If colTrigs IsNot Nothing Then
            If colTrigs.ContainsKey(sKey) Then
                Dim obj As Object = Nothing
                obj = colTrigs.Item(sKey)
                If obj IsNot Nothing Then
                    Dim Ret As strTrigger
                    Ret.Result = False
                    If TypeOf obj Is MyTrigger1Ton Then
                        Ret.WhichTrigger = eTriggerType.OneTon
                        Ret.TrigObj = obj
                        Ret.Result = True
                        Return Ret
                    ElseIf TypeOf obj Is MyTrigger2Shoe Then
                        Ret.WhichTrigger = eTriggerType.TwoVolts
                        Ret.TrigObj = obj
                        Ret.Result = True
                        Return Ret
                    End If
                End If
            End If
        End If
        Dim Bad As strTrigger
        Bad.WhichTrigger = eTriggerType.Unknown
        Bad.Result = False
        Bad.TrigObj = Nothing
        Return Bad
    End Function
    Friend Function ActionFromInfo(ByVal ActInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As strAction
        Dim sKey As String = ""
        sKey = "K" & ActInfo.UID.ToString
        If colActs IsNot Nothing Then
            If colActs.ContainsKey(sKey) Then
                Dim obj As Object = Nothing
                obj = colActs.Item(sKey)
                If obj IsNot Nothing Then
                    Dim Ret As strAction
                    Ret.Result = False
                    If TypeOf obj Is MyAction1EvenTon Then
                        Ret.WhichAction = eActionType.Weight
                        Ret.ActObj = obj
                        Ret.Result = True
                        Return Ret
                    ElseIf TypeOf obj Is MyAction2Euro Then
                        Ret.WhichAction = eActionType.Voltage
                        Ret.ActObj = obj
                        Ret.Result = True
                        Return Ret
                    End If
                End If
            End If
        End If
        Dim Bad As strAction
        Bad.WhichAction = eActionType.Unknown
        Bad.Result = False
        Bad.ActObj = Nothing
        Return Bad
    End Function


    Friend Function SerializeObject(ByRef ObjIn As Object, ByRef bteOut() As Byte) As Boolean
        If ObjIn Is Nothing Then Return False
        Dim str As New MemoryStream
        Dim sf As New Binary.BinaryFormatter

        Try
            sf.Serialize(str, ObjIn)
            ReDim bteOut(Convert.ToInt32(str.Length - 1))
            bteOut = str.ToArray
            Return True
        Catch ex As Exception
            Log(IFACE_NAME & " Error: Serializing object " & ObjIn.ToString & " :" & ex.Message, LogType.LOG_TYPE_ERROR)
            Return False
        End Try

    End Function

    Friend Function SerializeObject(ByRef ObjIn As Object, ByRef HexOut As String) As Boolean
        If ObjIn Is Nothing Then Return False
        Dim str As New MemoryStream
        Dim sf As New Binary.BinaryFormatter
        Dim bteOut() As Byte

        Try
            sf.Serialize(str, ObjIn)
            ReDim bteOut(Convert.ToInt32(str.Length - 1))
            bteOut = str.ToArray
            HexOut = ""
            For i As Integer = 0 To bteOut.Length - 1
                HexOut &= bteOut(i).ToString("x2").ToUpper
            Next
            Return True
        Catch ex As Exception
            Log(IFACE_NAME & " Error: Serializing (Hex) object " & ObjIn.ToString & " :" & ex.Message, LogType.LOG_TYPE_ERROR)
            Return False
        End Try

    End Function

    Public Function DeSerializeObject(ByRef bteIn() As Byte, ByRef ObjOut As Object) As Boolean
        ' Almost immediately there is a test to see if ObjOut is NOTHING.  The reason for this
        '   when the ObjOut is suppose to be where the deserialized object is stored, is that 
        '   I could find no way to test to see if the deserialized object and the variable to 
        '   hold it was of the same type.  If you try to get the type of a null object, you get
        '   only a null reference exception!  If I do not test the object type beforehand and 
        '   there is a difference, then the InvalidCastException is thrown back in the CALLING
        '   procedure, not here, because the cast is made when the ByRef object is cast when this
        '   procedure returns, not earlier.  In order to prevent a cast exception in the calling
        '   procedure that may or may not be handled, I made it so that you have to at least 
        '   provide an initialized ObjOut when you call this - ObjOut is set to nothing after it 
        '   is typed.
        If bteIn Is Nothing Then Return False
        If bteIn.Length < 1 Then Return False
        If ObjOut Is Nothing Then Return False
        Dim str As MemoryStream
        Dim sf As New Binary.BinaryFormatter
        Dim ObjTest As Object
        Dim TType As System.Type
        Dim OType As System.Type
        Try
            OType = ObjOut.GetType
            ObjOut = Nothing
            str = New MemoryStream(bteIn)
            ObjTest = sf.Deserialize(str)
            If ObjTest Is Nothing Then Return False
            TType = ObjTest.GetType
            'If Not TType.Equals(OType) Then Return False
            ObjOut = ObjTest
            If ObjOut Is Nothing Then Return False
            Return True
        Catch exIC As InvalidCastException
            Return False
        Catch ex As Exception
            WriteLog(ErrorLog, " Error: DeSerializing object: " & ex.Message, 0)
            Return False
        End Try

    End Function

    'Public Function DeSerializeObject(ByRef HexIn As String, ByRef ObjOut As Object) As Boolean
    '    ' Almost immediately there is a test to see if ObjOut is NOTHING.  The reason for this
    '    '   when the ObjOut is suppose to be where the deserialized object is stored, is that 
    '    '   I could find no way to test to see if the deserialized object and the variable to 
    '    '   hold it was of the same type.  If you try to get the type of a null object, you get
    '    '   only a null reference exception!  If I do not test the object type beforehand and 
    '    '   there is a difference, then the InvalidCastException is thrown back in the CALLING
    '    '   procedure, not here, because the cast is made when the ByRef object is cast when this
    '    '   procedure returns, not earlier.  In order to prevent a cast exception in the calling
    '    '   procedure that may or may not be handled, I made it so that you have to at least 
    '    '   provide an initialized ObjOut when you call this - ObjOut is set to nothing after it 
    '    '   is typed.
    '    If HexIn Is Nothing Then Return False
    '    If String.IsNullOrEmpty(HexIn.Trim) Then Return False
    '    If ObjOut Is Nothing Then Return False

    '    Dim str As MemoryStream
    '    Dim sf As New Binary.BinaryFormatter
    '    Dim ObjTest As Object
    '    Dim TType As System.Type
    '    Dim OType As System.Type

    '    Dim bteIn() As Byte
    '    Dim HowMany As Integer

    '    Try
    '        HowMany = Convert.ToInt32((HexIn.Length / 2) - 1)
    '        ReDim bteIn(HowMany)
    '        For i As Integer = 0 To HowMany
    '            'bteIn(i) = CByte("&H" & HexIn.Substring(i * 2, 2))
    '            bteIn(i) = Byte.Parse(HexIn.Substring(i * 2, 2), Globalization.NumberStyles.HexNumber)
    '        Next
    '        OType = ObjOut.GetType
    '        ObjOut = Nothing
    '        str = New MemoryStream(bteIn)
    '        ObjTest = sf.Deserialize(str)
    '        If ObjTest Is Nothing Then Return False
    '        TType = ObjTest.GetType
    '        If Not TType.Equals(OType) Then Return False
    '        ObjOut = ObjTest
    '        If ObjOut Is Nothing Then Return False
    '        Return True
    '    Catch exIC As InvalidCastException
    '        Return False
    '    Catch ex As Exception
    '        Log(IFACE_NAME & " Error: DeSerializing object: " & ex.Message, LogType.LOG_TYPE_ERROR)
    '        Return False
    '    End Try

    'End Function
End Module
