﻿Imports System.Text
Imports System.IO
Imports System.Threading
Imports Newtonsoft.Json
Imports System.Net.Sockets
Imports Newtonsoft.Json.Linq
Imports Newtonsoft.Json.Converters
Imports System.Xml.Linq
<Serializable()>
Public Class clsRootConfigOptions
    Public Property ThermostatName As String
    Public Property AirDevice As Boolean ' Wireless device with battery yes/no
    Public Property UseFloorTempSensor As Boolean
    Public Property UseAirTempSensor As Boolean

    Public Sub New(Optional ByVal Name As String = "")
        ThermostatName = Name
        AirDevice = False
        UseAirTempSensor = False
        UseFloorTempSensor = False
    End Sub
End Class

Public Class NeoResponse
    Public Property result As String
    Public Property [error] As String
End Class

Public Class clsNeoStatMode
    Public Property THERMOSTAT As Boolean
    Public Property TIMECLOCK As Boolean
End Class

Public Class clsNeoDeviceInfo
    Public Property AWAY As Boolean
    Public Property COOLING As Boolean
    Public Property COOLING_ENABLED As Boolean
    Public Property COOLING_TEMPERATURE_IN_WHOLE_DEGREES As Integer
    Public Property COOL_INP As Boolean
    Public Property COUNT_DOWN_TIME As String
    Public Property CRADLE_PAIRED_TO_REMOTE_SENSOR As Boolean
    Public Property CRADLE_PAIRED_TO_STAT As Boolean
    Public Property CURRENT_FLOOR_TEMPERATURE As Double
    Public Property CURRENT_SET_TEMPERATURE As Double
    Public Property CURRENT_TEMPERATURE As Double
    Public Property DEMAND As Boolean
    Public Property DEVICE_TYPE As Integer
    Public Property ENABLE_BOILER As Boolean
    Public Property ENABLE_COOLING As Boolean
    Public Property ENABLE_PUMP As Boolean
    Public Property ENABLE_VALVE As Boolean
    Public Property ENABLE_ZONE As Boolean
    Public Property FAILSAFE_STATE As Boolean
    Public Property FAIL_SAFE_ENABLED As Boolean
    Public Property FLOOR_LIMIT As Boolean
    Public Property FULL_PARTIAL_LOCK_AVAILABLE As Boolean
    Public Property HEAT_COOL_MODE As Boolean
    Public Property HEATING As Boolean
    Public Property HOLD_TEMPERATURE As Double
    Public Property HOLD_TIME As String
    Public Property HOLIDAY As Boolean
    Public Property HOLIDAY_DAYS As Integer
    Public Property HUMIDITY As Double
    Public Property LOCK As Boolean
    Public Property LOCK_PIN_NUMBER As String
    Public Property LOW_BATTERY As Boolean
    Public Property MAX_TEMPERATURE As Double
    Public Property MIN_TEMPERATURE As Double
    Public Property MODULATION_LEVEL As Integer
    Public Property NEXT_ON_TIME As String
    Public Property OFFLINE As Boolean
    Public Property OUPUT_DELAY As Boolean
    Public Property OUTPUT_DELAY As Integer
    Public Property PREHEAT As Boolean
    Public Property PREHEAT_TIME As String
    Public Property PROGRAM_MODE As String
    Public Property PUMP_DELAY As Boolean
    Public Property RADIATORS_OR_UNDERFLOOR As Boolean
    Public Property SENSOR_SELECTION As String
    Public Property SET_COUNTDOWN_TIME As Integer
    Public Property STANDBY As Boolean
    ' Public Property STAT_MODE As JObject
    Public Property STAT_MODE As clsNeoStatMode
    Public Property TEMPERATURE_FORMAT As Boolean
    Public Property TEMP_HOLD As Boolean
    Public Property TIMECLOCK_MODE As Boolean
    Public Property TIMER As Boolean
    Public Property TIME_CLOCK_OVERRIDE_BIT As Boolean
    Public Property VERSION_NUMBER As String
    Public Property WRITE_COUNT As Integer
    Public Property ZONE_1PAIRED_TO_MULTILINK As Boolean
    Public Property ZONE1_OR_2 As Boolean
    Public Property ZONE_2_PAIRED_TO_MULTILINK As Boolean
    Public Property device As String
End Class

'Public Class NeoinfoConverter
'    Inherits CustomCreationConverter(Of clsNeoInfo)

'    Public Overrides Function Create(objectType As Type) As clsNeoInfo
'        Return New clsNeoInfo
'    End Function
'End Class

'Public Class NeoDeviceConverter
'    Inherits CustomCreationConverter(Of clsNeoDeviceInfo)

'    Public Overrides Function Create(objectType As Type) As clsNeoDeviceInfo
'        Return New clsNeoDeviceInfo
'    End Function
'End Class

'Public Class clsNeoInfo
'    'Public Property devices As Collection
'    Public Property devices() As clsNeoDeviceInfo
'End Class

Public Class clsComfortPair
    Public Property setPoint As Integer
    Public Property setTime As Date
End Class

Public Class clsExtractedComfortPairs
    Public Property leave As clsComfortPair
    Public Property [return] As clsComfortPair
    Public Property sleep As clsComfortPair
    Public Property wake As clsComfortPair
End Class

Public Class clsComfortSetting
    Public Property leave As Collection
    Public Property [return] As Collection
    Public Property sleep As Collection
    Public Property wake As Collection
End Class

Public Class clsComfortDays_Get
    Public Property monday As clsComfortSetting
    Public Property tuesday As clsComfortSetting
    Public Property wednesday As clsComfortSetting
    Public Property thursday As clsComfortSetting
    Public Property friday As clsComfortSetting
    Public Property saturday As clsComfortSetting
    Public Property sunday As clsComfortSetting
End Class

Public Class clsComfortDays_Set
    Public Property monday As clsExtractedComfortPairs
    Public Property tuesday As clsExtractedComfortPairs
    Public Property wednesday As clsExtractedComfortPairs
    Public Property thursday As clsExtractedComfortPairs
    Public Property friday As clsExtractedComfortPairs
    Public Property saturday As clsExtractedComfortPairs
    Public Property sunday As clsExtractedComfortPairs
End Class

Enum days As Integer
    Monday = 0
    Tuesday = 1
    Wednesday = 2
    Thursday = 3
    Friday = 4
    Saturday = 5
    Sunday = 6
End Enum

Enum Levels As Integer
    Leave = 0
    [Return] = 1
    Sleep = 2
    Wake = 3
End Enum

Public Module NeoJSON
    Friend SM As String = """"
    Dim JSON_L As String = "{" & SM
    Dim JSON_Mid As String = SM & ":"
    Dim JSON_Mid_Arr As String = JSON_Mid & "["
    Dim JSON_R As String = "}" & Chr(0)
    Dim JSON_R_Arr As String = "]" & JSON_R

    Public ReadOnly Property NeoDummy As UShort
        Get
            NeoDummy = NeoFirmware
        End Get
    End Property

    Public ReadOnly Property NeoInfo As Boolean
        ' Returns True if Info could be read and False if not
        Get
            Dim ReturnJSON As String = ""
            Dim JSONDeviceMaster As JObject = Nothing
            Dim sb As New StringBuilder()
            Dim sw As New StringWriter(sb)
            Try
                Using wr As JsonWriter = New JsonTextWriter(sw)
                    wr.Formatting = Formatting.None
                    wr.WriteStartObject()
                    wr.WritePropertyName("INFO")
                    wr.WriteValue(0)
                    wr.WriteEndObject()
                End Using
            Catch ex As Exception
                WriteLog(ErrorLog, "Problem reading INFO. Error message was: " & ex.Message, 0)
                Return False
            End Try
            'sb.Clear()
            'sb.Append("{""INFO"":0}")
            ''sb.Append(vbNullChar)
            ''sb.Append(vbCr)
            ''sb.Append(vbLf)
            Dim test As String = sb.ToString
            Dim t3 As String = ""
            Try
                ReturnJSON = JSONsendReceive(sb.ToString)
                t3 = ReturnJSON.ToString
            Catch ex As Exception
                WriteLog(WarningLog, "Problem reading INFO from . Error message was: " & ex.Message, 0)
                'If hs.GetOSType = HomeSeerAPI.eOSType.linux Then
                '    WriteLog(ErrorLog, "Please ensure numerics and linq packages are installed for mono on linux", 0)
                '    WriteLog(ErrorLog, "Use the following commands (or similar) on Raspberry Pi  / Hometroller SEL to install:", 0)
                '    WriteLog(ErrorLog, "sudo apt-get install libmono-system-numerics4.0-cil", 0)
                '    WriteLog(ErrorLog, "sudo apt-get install libmono-system-xml-linq4.0-cil", 0)
                'End If
                WriteLog(ErrorLog, "Data received from Heatmiser NEO gateway was: " & ReturnJSON, 0)
                Return False
            End Try
            Try
                Dim RootDevice As Integer = -1
                Dim DeviceName As String = "UNKNOWN"

                Dim TStat As clsNeoDeviceInfo
                JSONDeviceMaster = JObject.Parse(ReturnJSON)
                Dim DeviceString As String = ""
                Dim JSONDevices As JArray
                For Each AllDevicesLine In JSONDeviceMaster
                    DeviceString = AllDevicesLine.Value.ToString
                    JSONDevices = JArray.Parse(DeviceString)
                    _TStatCount = JSONDevices.Count
                    Dim i As Integer = 0
                    ReDim _TStatNames(_TStatCount)
                    For Each DeviceLine In JSONDevices
                        DeviceString = DeviceLine.ToString
                        TStat = JsonConvert.DeserializeObject(Of clsNeoDeviceInfo)(DeviceString)
                        ' Now process this device
                        DeviceName = TStat.device
                        i += 1
                        _TStatNames(i) = DeviceName
                        ' Check if it exists and create if not, then update child devices
                        RootDevice = hs.DeviceExistsAddress(IFACE_NAME & "-" & DeviceName & _ROOT, False)
                        If RootDevice = -1 Then CreateDeviceSet(DeviceName)
                        ' Now update devices
                        If TStat.OFFLINE Then
                            UpdateHSDeviceString(DeviceName, _ROOT, -1, "Offline")
                        Else
                            ' ROOT
                            UpdateHSDeviceString(DeviceName, _ROOT, 0, "No Errors")
                            ' AWAY device
                            If TStat.AWAY Then UpdateHSDeviceValue(DeviceName, _AWAY, 1) Else UpdateHSDeviceValue(DeviceName, _AWAY, 0)
                            ' Hold Mode
                            Dim TimeLeft As String = TStat.HOLD_TIME
                            'Dim TimeLeftHours As Integer = Val(Left(TimeOfDay, InStr(TimeLeft, ":") - 1))
                            'Dim TimeLeftMins As Integer = Val(Right(TimeLeft, Len(TimeLeft) - InStr(TimeLeft, ":")))
                            Dim TimeLeftHours As Integer = Val(Left(TimeLeft, InStr(TimeLeft, ":") - 1))
                            Dim TimeLeftMins As Integer = Val(Right(TimeLeft, Len(TimeLeft) - InStr(TimeLeft, ":")))

                            Dim TimeLeftTotal As Integer = TimeLeftHours * 60 + TimeLeftMins
                            Dim TimeLeftString As String = Format(TimeLeftHours, "00") & ":" & Format(TimeLeftMins, "00")
                            If TimeLeftTotal = 0 Then UpdateHSDeviceString(DeviceName, _HOLD, 0, "OFF") Else UpdateHSDeviceString(DeviceName, _HOLD, TimeLeftTotal, TimeLeftString)
                            ' Lock
                            If TStat.LOCK Then UpdateHSDeviceString(DeviceName, _LOCK, 1, "Locked") Else UpdateHSDeviceString(DeviceName, _LOCK, -2, "Unlocked")
                            ' SetPoint
                            UpdateHSDeviceValue(DeviceName, _SETPOINT, TStat.CURRENT_SET_TEMPERATURE)
                            ' Current Temperature
                            UpdateHSDeviceValue(DeviceName, _TEMPERATURE, TStat.CURRENT_TEMPERATURE)
                            'Standby Mode
                            If TStat.STANDBY Then UpdateHSDeviceValue(DeviceName, _STANDBY, 1) Else UpdateHSDeviceValue(DeviceName, _STANDBY, 0)

                            Dim CurIdx As Integer = ThermostatConfigOptions.FindIndex(Function(p) p.ThermostatName = DeviceName)
                            ' Floor Temperature
                            If TStat.CURRENT_FLOOR_TEMPERATURE <> 255 Then
                                If CurIdx <> -1 Then
                                    If ThermostatConfigOptions(CurIdx).UseFloorTempSensor Then UpdateHSDeviceValue(DeviceName, _FLOORTEMPERATURE, TStat.CURRENT_FLOOR_TEMPERATURE)
                                End If
                            End If
                            ' Battery Device
                            If CurIdx <> -1 Then
                                If ThermostatConfigOptions(CurIdx).AirDevice Then
                                    Dim NewVal As Byte = 100
                                    If TStat.LOW_BATTERY Then NewVal = 0
                                    UpdateHSDeviceValue(DeviceName, _BATTERY, NewVal)
                                End If
                            End If

                            ' Heat Device
                            If TStat.HEATING Then UpdateHSDeviceValue(DeviceName, _HEAT, 1) Else UpdateHSDeviceValue(DeviceName, _HEAT, 0)
                            '' Hold Temperature
                            ''UpdateHSDeviceValue(DeviceName, _HOLDTEMP, TStat.HOLD_TEMPERATURE)

                        End If
                    Next
                Next

            Catch ex As Exception
                WriteLog(WarningLog, "Problem deserialising INFO. Error message was: " & ex.Message, 0)
                'If hs.GetOSType = HomeSeerAPI.eOSType.linux Then
                '    WriteLog(ErrorLog, "Please ensure numerics and linq packages are installed for mono on linux", 0)
                '    WriteLog(ErrorLog, "Use the following commands (or similar) on Raspberry Pi to install:", 0)
                '    WriteLog(ErrorLog, "sudo apt-get install libmono-system-numerics4.0-cil", 0)
                '    WriteLog(ErrorLog, "sudo apt-get install libmono-system-xml-linq4.0-cil", 0)
                '    WriteLog(ErrorLog, "Data received from Heatmiser NEO gateway was: " & ReturnJSON, 0)
                'End If
                WriteLog(ErrorLog, "Data received from Heatmiser NEO gateway was: " & ReturnJSON, 0)
                Return False
            End Try

            Return True
        End Get
    End Property

    Public WriteOnly Property AwayMode(TStat As String) As Boolean
        Set(value As Boolean)
            ' True=Away On, False=Away Off
            Dim OnOff As String = "OFF"
            If value Then OnOff = "ON"

            Dim Cmd As String = JSON_L & "AWAY_" & OnOff & JSON_Mid & SM & TStat & SM & JSON_R

            SendAndReceiveTCP(TStat, Cmd, _AWAY)
        End Set
    End Property

    Public WriteOnly Property Standby(TStat As String) As Boolean
        Set(value As Boolean)
            ' True=Away On, False=Away Off
            Dim OnOff As String = "OFF"
            If value Then OnOff = "ON"

            Dim Cmd As String = JSON_L & "FROST_" & OnOff & JSON_Mid & SM & TStat & SM & JSON_R

            SendAndReceiveTCP(TStat, Cmd, _STANDBY)
        End Set
    End Property

    Public WriteOnly Property Lock(TStat As String) As String
        Set(value As String)
            ' If Value is OFF then Lock is tuned off, otherwise set with the code given in value
            Dim Cmd As String = ""
            If value = "OFF" Then
                Cmd = JSON_L & "UNLOCK" & JSON_Mid & SM & TStat & SM & JSON_R
            Else
                Dim PIN As String = Left(value, 4)
                Cmd = JSON_L & "LOCK" & JSON_Mid_Arr & "[" & Mid(value, 1, 1) & "," & Mid(value, 2, 1) & "," & Mid(value, 3, 1) & "," & _
                    Mid(value, 4, 1) & "]," & SM & TStat & SM & JSON_R_Arr
            End If
            SendAndReceiveTCP(TStat, Cmd, _LOCK)
        End Set
    End Property

    Public WriteOnly Property Hold(TStat As String) As Integer
        Set(value As Integer)
            Dim Cmd As String = ""
            If value = 0 Then
                Cmd = JSON_L & "TIMER_HOLD_OFF" & JSON_Mid_Arr & "0," & SM & TStat & SM & JSON_R_Arr
            Else
                Cmd = JSON_L & "TIMER_HOLD_ON" & JSON_Mid_Arr & value & "," & SM & TStat & SM & JSON_R_Arr
            End If
            SendAndReceiveTCP(TStat, Cmd, _HOLD, Left(value, 4))
        End Set
    End Property

    Public ReadOnly Property NeoFirmware As String
        Get
            Dim Cmd As String = JSON_L & "FIRMWARE" & JSON_Mid & "0" & JSON_R

            SendAndReceiveTCP(0, Cmd, "FIRMWARE")
            NeoFirmware = "" 'UPDATE THIS ONE
            Return False
        End Get
    End Property

    Public WriteOnly Property NeoSetPoint(Devices() As String) As Integer
        Set(value As Integer)
            Dim sb As New StringBuilder()
            Dim sw As New StringWriter(sb)
            Dim i As Integer
            Using wr As JsonWriter = New JsonTextWriter(sw)
                wr.Formatting = Formatting.None
                wr.WriteStartObject()
                wr.WritePropertyName("SET_TEMP")
                wr.WriteStartArray()
                wr.WriteValue(value)
                For i = 0 To Devices.Length - 1
                    wr.WriteValue(Devices(i))
                Next
                wr.WriteEndArray()
                wr.WriteEndObject()
            End Using
            Dim ReturnJSON As String = JSONsendReceive(sb.ToString)
            If ReturnJSON <> "" Then
                Dim Response As NeoResponse = JsonConvert.DeserializeObject(Of NeoResponse)(ReturnJSON)
                If Response.result <> "" Then
                    For i = 0 To Devices.Length - 1
                        UpdateHSDeviceValue(Devices(i), _SETPOINT, value)
                    Next
                    WriteLog(DebugLog, "Setpoint update to " & value.ToString & " was successful", 3)
                End If
                If Response.error <> "" Then Console.WriteLine("Problem: " & Response.error)
            End If
        End Set
    End Property

    Friend currentComfortLevelArray(6, 3) As clsComfortPair

    Friend Sub ComfortLevelsUpdatePair(ByVal dayNo As days, ByVal Level As Levels, ByVal curSetPoint As Integer, ByVal setTime As Date)
        If currentComfortLevelArray(dayNo, Level) Is Nothing Then currentComfortLevelArray(dayNo, Level) = New clsComfortPair
        currentComfortLevelArray(dayNo, Level).setPoint = curSetPoint
        currentComfortLevelArray(dayNo, Level).setTime = setTime
    End Sub

    Friend Sub ComfortLevelsUpdateSet(ByVal dayNo As days, ByVal Settings As clsComfortSetting)
        Dim setPoint As Integer
        Dim setTime As Date
        Dim timeString As String

        ' Leave
        setPoint = Settings.leave.Item(2)
        timeString = Settings.leave.Item(1)
        If timeString = "24:00" Then timeString = "0:00"
        setTime = DateTime.Parse(timeString)
        ComfortLevelsUpdatePair(dayNo, Levels.Leave, setPoint, setTime)

        ' Return
        setPoint = Settings.return.Item(2)
        timeString = Settings.return.Item(1)
        If timeString = "24:00" Then timeString = "0:00"
        setTime = DateTime.Parse(timeString)
        ComfortLevelsUpdatePair(dayNo, Levels.Return, setPoint, setTime)

        ' Sleep
        setPoint = Settings.sleep.Item(2)
        timeString = Settings.sleep.Item(1)
        If timeString = "24:00" Then timeString = "0:00"
        setTime = DateTime.Parse(timeString)
        ComfortLevelsUpdatePair(dayNo, Levels.Sleep, setPoint, setTime)

        ' Wake
        setPoint = Settings.wake.Item(2)
        timeString = Settings.wake.Item(1)
        If timeString = "24:00" Then timeString = "0:00"
        setTime = DateTime.Parse(timeString)
        ComfortLevelsUpdatePair(dayNo, Levels.Wake, setPoint, setTime)
    End Sub

    Friend Function ExtractComfortPairs(ByRef Settings As clsComfortSetting) As clsExtractedComfortPairs
        Dim setPoint As Integer
        Dim setTime As Date
        Dim timeString As String
        ExtractComfortPairs = New clsExtractedComfortPairs

        ' Leave
        setPoint = Settings.leave.Item(2)
        timeString = Settings.leave.Item(1)
        If timeString = "24:00" Then timeString = "0:00"
        setTime = DateTime.Parse(timeString)
        ExtractComfortPairs.leave = New clsComfortPair
        ExtractComfortPairs.leave.setPoint = setPoint
        ExtractComfortPairs.leave.setTime = setTime

        ' Return
        setPoint = Settings.return.Item(2)
        timeString = Settings.return.Item(1)
        If timeString = "24:00" Then timeString = "0:00"
        setTime = DateTime.Parse(timeString)
        ExtractComfortPairs.return = New clsComfortPair
        ExtractComfortPairs.return.setPoint = setPoint
        ExtractComfortPairs.return.setTime = setTime

        ' Sleep
        setPoint = Settings.sleep.Item(2)
        timeString = Settings.sleep.Item(1)
        If timeString = "24:00" Then timeString = "0:00"
        setTime = DateTime.Parse(timeString)
        ExtractComfortPairs.sleep = New clsComfortPair
        ExtractComfortPairs.sleep.setPoint = setPoint
        ExtractComfortPairs.sleep.setTime = setTime

        ' Wake
        setPoint = Settings.wake.Item(2)
        timeString = Settings.wake.Item(1)
        If timeString = "24:00" Then timeString = "0:00"
        setTime = DateTime.Parse(timeString)
        ExtractComfortPairs.wake = New clsComfortPair
        ExtractComfortPairs.wake.setPoint = setPoint
        ExtractComfortPairs.wake.setTime = setTime

        Return ExtractComfortPairs
    End Function

    Public ReadOnly Property NeoComfortLevels(Devices() As String) As clsComfortDays_Get
        Get
            Dim deSerComfortLevels As New clsComfortDays_Get
            Try
                If Devices.Length = 0 Then Return Nothing

                Dim sb As New StringBuilder()
                Dim sw As New StringWriter(sb)
                Dim i As Integer
                Using wr As JsonWriter = New JsonTextWriter(sw)
                    wr.Formatting = Formatting.None
                    wr.WriteStartObject()
                    wr.WritePropertyName("READ_COMFORT_LEVELS")
                    For i = 0 To Devices.Length - 1
                        If Devices(i) = "" Then Return Nothing
                        wr.WriteValue(Devices(i))
                    Next
                    wr.WriteEndObject()
                End Using
                Dim ReturnJSON As String = JSONsendReceive(sb.ToString)

                Dim JSONRooms As JObject = JObject.Parse(ReturnJSON)
                Dim JSONDays As JObject

                Dim s As String
                For Each Room In JSONRooms ' Enumerate Devices
                    s = Room.Value.ToString
                    JSONDays = JObject.Parse(s)
                    deSerComfortLevels = JsonConvert.DeserializeObject(Of clsComfortDays_Get)(s)
                Next
            Catch ex As Exception
                WriteLog(ErrorLog, "Problem reading Comfort Levels. Error message was: " & ex.Message, 0)
            End Try
            Return deSerComfortLevels
        End Get
        'Set(value As clsComfortDays)
        'Dim Levels As New NeoComfortLevels
        'Levels.Office = "office"
        'Levels.Days.sunday.leave.SetPoint = 25
        'Levels.Days.sunday.leave.Time = Now()
        'Dim jsonstr As String = JsonConvert.SerializeObject(Levels, Formatting.None)
        'End Set
    End Property

    Friend Function JSONsendReceive(ByVal Message As String) As String
        Try
            'Console.WriteLine("JSONsendReceive command: " & Message)
            Message = Message & Chr(0)
            Dim port As Int32 = _TCPPort
            Dim server As String = _IPAddress
            Dim client As New TcpClient(server, port)

            ' Translate the passed message into ASCII and store it as a Byte array. 
            Dim data As [Byte]() = StrToByteArray(Message, True)

            ' Get a client stream for reading and writing. 
            Dim stream As NetworkStream = client.GetStream()

            stream.ReadTimeout = 2000
            stream.WriteTimeout = 2000

            ' Send the message to the connected TcpServer. 
            stream.Write(data, 0, data.Length)

            ' Receive the TcpServer.response. 
            ' Buffer to store the response bytes.
            data = New [Byte](65536) {}

            ' String to store the response ASCII representation. 
            Dim responseData As [String] = [String].Empty

            ' Read the first batch of the TcpServer response bytes. 
            Dim bytes As Int32 = stream.Read(data, 0, data.Length)
            WriteLog(DebugLog, "Bytes Read: " & bytes, 5)
            ReDim Preserve data(bytes - 1)
            responseData = BytesToString(data)

            Thread.Sleep(100) ' wait 100msec to allow for more data to be sent from the gateway
            If stream.DataAvailable Then WriteLog(DebugLog, "More Data Available", 5) Else WriteLog(DebugLog, "End of stream...", 5)
            While stream.DataAvailable
                bytes = stream.Read(data, 0, data.Length)
                ReDim Preserve data(bytes - 1)
                responseData = responseData & BytesToString(data)
                WriteLog(DebugLog, "Bytes Read: " & bytes, 5)
            End While

            WriteLog(DebugLog, "ResponseData Length: " & responseData.Length, 5)

            ' Close everything.
            stream.Close()
            client.Close()

            Return responseData
        Catch e As ArgumentNullException
            Console.WriteLine("ArgumentNullException: {0}", e)
            WriteLog(ErrorLog, "ArgumentNullException: " & e.ToString, 0)
            'UpdateHSDeviceString(Index, _ROOT, -1002, "Problems communicating with NEO Hub")
        Catch e As SocketException
            Console.WriteLine("SocketException: {0}", e)
            WriteLog(ErrorLog, "TCP Connection Error: " & e.ToString, 0)
            'UpdateHSDeviceString(Index, _ROOT, -1002, "Problems communicating with NEO Hub")
        Catch e As Exception
            Console.WriteLine("Error: {0}", e)
            ' WriteLog(ErrorLog, "TCP Connection Error: " & e.ToString, 0)
            'UpdateHSDeviceValue(Index, _ROOT, -1002)
        End Try
        Return ""
    End Function



End Module

