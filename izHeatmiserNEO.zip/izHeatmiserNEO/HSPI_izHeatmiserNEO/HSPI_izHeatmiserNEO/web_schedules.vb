﻿Imports System.Text
Imports System.Web
Imports Scheduler
Imports HomeSeerAPI
Imports Newtonsoft.Json
Imports System.IO

Public Class web_schedules
    Inherits clsPageBuilder
    Dim TimerEnabled As Boolean
    Public hspiref As HSPI

    Dim sTStat As Integer = 0
    Dim sSevenDayIdx As UShort = 0

    Public Sub New(ByVal pagename As String)
        MyBase.New(pagename)
    End Sub

    Private Function BuildPair(ByRef Level As String, ByRef setTime As String, ByRef setPoint As String) As String
        Dim sb As New StringBuilder()
        Dim sw As New StringWriter(sb)
        Using wr As JsonWriter = New JsonTextWriter(sw)
            wr.WritePropertyName(Level)
            wr.WriteStartArray()
            wr.WriteRawValue("""" & setTime & """")
            wr.WriteRawValue(setPoint)
            wr.WriteEndArray()
        End Using
        BuildPair = sb.ToString
    End Function

    Public Overrides Function postBackProc(page As String, data As String, user As String, userRights As Integer) As String

        Dim parts As Collections.Specialized.NameValueCollection
        parts = HttpUtility.ParseQueryString(data)
        'Dim sKey As String
        'Dim sValue As String
        'Dim n, m As Integer

        Select Case parts("id")
            Case "oTStat"
                sTStat = Val(parts("TStat").Trim)
                Me.divToUpdate.Add("schedule", BuildSchedule)

                'Case "SevenDaySchedule"
                '    sValue = parts("SevenDaySchedule").Trim
                '    If (sTStat > 0) And (sValue <> "") Then
                '        SevenDaySchedule(sTStat) = CBool(sValue)
                '        _SevenDaySchedule(sTStat) = SevenDaySchedule(sTStat)
                '    End If
                '    Dim SchWrite As UShort = 0
                '    If _SevenDaySchedule(sTStat) Then SchWrite = 1
                '    '   WIFI_Write(sTStat, 16, {SchWrite})
                '    If _SevenDaySchedule(sTStat) Then
                '        sSevenDayIdx = 1
                '        SevenDaySchedule(sTStat) = True
                '    Else
                '        sSevenDayIdx = 2
                '        SevenDaySchedule(sTStat) = False
                '    End If
                '    Me.divToUpdate.Add("sevenday", BuildSevenDayDrop)
            Case "update"
                sTStat = Val(parts("TStat").Trim)
                If sTStat > 0 Then ' We have a valid thermostat
                    Dim sb As New StringBuilder()
                    Dim sw As New StringWriter(sb)
                    Using wr As JsonWriter = New JsonTextWriter(sw)
                        wr.Formatting = Formatting.None
                        wr.WriteStartObject()
                        wr.WritePropertyName("SET_COMFORT_LEVELS")
                        wr.WriteStartArray()

                        ' Write Monday's values
                        wr.WriteStartObject() ' Days
                        wr.WritePropertyName("monday") ' Monday's set
                        wr.WriteStartObject()

                        wr.WriteRaw(BuildPair("leave", parts("wd_leave_time"), parts("wd_leave_sp")) & ",")
                        wr.WriteRaw(BuildPair("return", parts("wd_return_time"), parts("wd_return_sp")) & ",")
                        wr.WriteRaw(BuildPair("sleep", parts("wd_sleep_time"), parts("wd_sleep_sp")) & ",")
                        wr.WriteRaw(BuildPair("wake", parts("wd_wake_time"), parts("wd_wake_sp")))

                        wr.WriteEndObject() ' Monday's set end 
                        'wr.WriteEndObject() ' Monday's set end 

                        ' Write Sunday's values
                        'wr.WriteStartObject() ' Days
                        wr.WritePropertyName("sunday") ' Monday's set
                        wr.WriteStartObject()

                        wr.WriteRaw(BuildPair("leave", parts("we_leave_time"), parts("we_leave_sp")) & ",")
                        wr.WriteRaw(BuildPair("return", parts("we_return_time"), parts("we_return_sp")) & ",")
                        wr.WriteRaw(BuildPair("sleep", parts("we_sleep_time"), parts("we_sleep_sp")) & ",")
                        wr.WriteRaw(BuildPair("wake", parts("we_wake_time"), parts("we_wake_sp")))

                        wr.WriteEndObject() ' Sunday's set end 
                        wr.WriteEndObject() ' Sunday's set end 


                        'wr.WriteEndObject() ' Days

                        wr.WriteStartArray() ' Devices
                        wr.WriteRawValue("""" & _TStatNames(sTStat) & """")
                        wr.WriteEndArray() ' Devices

                        wr.WriteEndArray()
                        wr.WriteEndObject()
                    End Using
                    'Debug.WriteLine(sb.ToString)
                    Dim ReturnJSON As String = JSONsendReceive(sb.ToString)
                    ' Debug.WriteLine(ReturnJSON)
                End If
        End Select

        Return MyBase.postBackProc(page, data, user, userRights)
    End Function

    'Public Function GetPagePlugin(ByVal pageName As String, ByVal user As String, ByVal userRights As Integer, ByVal queryString As String, instance As String) As String
    Public Function GetPagePlugin(ByVal pageName As String, ByVal user As String, ByVal userRights As Integer, ByVal queryString As String) As String
        Dim stb As New StringBuilder

        Try
            Me.reset()

            ' handle any queries like mode=something
            Dim parts As Collections.Specialized.NameValueCollection = Nothing
            If (queryString <> "") Then
                parts = HttpUtility.ParseQueryString(queryString)
            End If

            stb.Append(hs.GetPageHeader(pageName, "Schedules", "", "", False, False))

            'stb.Append(clsPageBuilder.DivStart("pluginpage", ""))

            ' a message area for error messages from jquery ajax postback (optional, only needed if using AJAX calls to get data)
            stb.Append(clsPageBuilder.DivStart("errormessage", "class='errormessage'"))
            stb.Append(clsPageBuilder.DivEnd)

            stb.Append(clsPageBuilder.FormStart("form", "form", "Post"))

            stb.Append(BuildContent)

            stb.Append("<br><br>")
            stb.Append(hs.GetPageFooter(True))

            stb.Append(clsPageBuilder.FormEnd)
            'stb.Append(clsPageBuilder.DivEnd)

            ' add the body html to the page
            Me.AddBody(stb.ToString)

            ' return the full page
            Return Me.BuildPage()

        Catch ex As Exception
            'WriteMon("Error", "Building page: " & ex.Message)
            Return "error - " & Err.Description
        End Try


    End Function

    Function BuildContent() As String
        Dim stb As New StringBuilder
        Dim i As Integer
        Dim dvRef As Integer
        Dim dv As Scheduler.Classes.DeviceClass = Nothing

        ' Start the form
        stb.Append(clsPageBuilder.FormStart("form", "form", "Post"))

        ' Thermostat Selector
        stb.Append("<hr><br><b>Thermostat: </b>")
        Dim dbTStat As New clsJQuery.jqDropList("TStat", PageName, True)
        dbTStat.id = "oTStat"
        dbTStat.AddItem("", "", False)

        For i = 1 To _TStatCount
            dvRef = hs.DeviceExistsAddress(IFACE_NAME & "-" & _TStatNames(i) & _ROOT, False)
            If dvRef <> -1 Then
                dv = hs.GetDeviceByRef(dvRef)
                dbTStat.AddItem("#" & i.ToString & " - " & dv.Location(Nothing) & " " & dv.Location2(Nothing), i.ToString, False)
            End If
        Next
        dbTStat.selectedItemIndex = 0
        stb.Append("<br>" & dbTStat.Build & "<br><br>")
        dv = Nothing

        ' Seven Day vs 5/2 Scheduling - FOR NOW ASSUME 5/2 ONLY
        'stb.Append("<br><b>Scheduling: <br>")
        'stb.Append("<div id='sevenday'>")
        'stb.Append(BuildSevenDayDrop)
        'stb.Append("</div><br><br>")

        ' Thermostat settings section below
        stb.Append("<br><br><hr>")
        Dim butUpdate As New clsJQuery.jqButton("update", "Click to update schedule", PageName, True)
        butUpdate.top = 4
        stb.Append(butUpdate.Build)

        'stb.Append("<div id='current_time'>" & DateTime.Now.ToString & "</div>" & vbCrLf)
        stb.Append("<div id='schedule'>")
        stb.Append(BuildSchedule)
        stb.Append("</div>")

        stb.Append(clsPageBuilder.FormEnd)

        Return stb.ToString
    End Function

    Function BuildSchedule() As String
        Dim stb As New StringBuilder

        Dim comfortLevels As clsComfortDays_Get = NeoComfortLevels({_TStatNames(sTStat)})
        Dim comfortSet As clsExtractedComfortPairs

        If comfortLevels IsNot Nothing Then
            comfortSet = ExtractComfortPairs(comfortLevels.monday)
            stb.Append("<table>")
            stb.Append("<tr><th><b>Weekdays</b></th><th>Wake</th><th>Leave</th><th>Return</th><th>Sleep</th></tr>")
            stb.Append("<tr><th>Time</th>")
            Dim tbTextbox As New clsJQuery.jqTextBox("wd_wake_time", "text", comfortSet.wake.setTime.ToShortTimeString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            tbTextbox = New clsJQuery.jqTextBox("wd_leave_time", "text", comfortSet.leave.setTime.ToShortTimeString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            tbTextbox = New clsJQuery.jqTextBox("wd_return_time", "text", comfortSet.return.setTime.ToShortTimeString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            tbTextbox = New clsJQuery.jqTextBox("wd_sleep_time", "text", comfortSet.sleep.setTime.ToShortTimeString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            stb.Append("</tr>")

            stb.Append("<tr><th>Set Point</th>")
            tbTextbox = New clsJQuery.jqTextBox("wd_wake_sp", "text", comfortSet.wake.setPoint.ToString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            tbTextbox = New clsJQuery.jqTextBox("wd_leave_sp", "text", comfortSet.leave.setPoint.ToString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            tbTextbox = New clsJQuery.jqTextBox("wd_return_sp", "text", comfortSet.return.setPoint.ToString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            tbTextbox = New clsJQuery.jqTextBox("wd_sleep_sp", "text", comfortSet.sleep.setPoint.ToString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            stb.Append("</tr>")

            stb.Append("<hr>")


            comfortSet = ExtractComfortPairs(comfortLevels.sunday)
            stb.Append("<table>")
            stb.Append("<tr><th><b>Weekend</b></th><th>Wake</th><th>Leave</th><th>Return</th><th>Sleep</th></tr>")
            stb.Append("<tr><th>Time</th>")
            tbTextbox = New clsJQuery.jqTextBox("we_wake_time", "text", comfortSet.wake.setTime.ToShortTimeString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            tbTextbox = New clsJQuery.jqTextBox("we_leave_time", "text", comfortSet.leave.setTime.ToShortTimeString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            tbTextbox = New clsJQuery.jqTextBox("we_return_time", "text", comfortSet.return.setTime.ToShortTimeString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            tbTextbox = New clsJQuery.jqTextBox("we_sleep_time", "text", comfortSet.sleep.setTime.ToShortTimeString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            stb.Append("</tr>")

            stb.Append("<hr>")

            stb.Append("<tr><th>Set Point</th>")
            tbTextbox = New clsJQuery.jqTextBox("we_wake_sp", "text", comfortSet.wake.setPoint.ToString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            tbTextbox = New clsJQuery.jqTextBox("we_leave_sp", "text", comfortSet.leave.setPoint.ToString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            tbTextbox = New clsJQuery.jqTextBox("we_return_sp", "text", comfortSet.return.setPoint.ToString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            tbTextbox = New clsJQuery.jqTextBox("we_sleep_sp", "text", comfortSet.sleep.setPoint.ToString, PageName, 3, True)
            tbTextbox.editable = True
            stb.Append("<td>" & tbTextbox.Build & "</td>")
            stb.Append("</tr>")


            stb.Append("</table")
        End If

        stb.Append("<hr>")

        Return stb.ToString
    End Function

    Function BuildSevenDayDrop() As String
        Dim stb As New StringBuilder

        Dim dbSchedule As New clsJQuery.jqDropList("SevenDaySchedule", PageName, True)
        dbSchedule.AddItem("", "", False)
        dbSchedule.AddItem("7 Day", "TRUE", False)
        dbSchedule.AddItem("5/2 Day", "FALSE", False)
        dbSchedule.selectedItemIndex = sSevenDayIdx
        stb.Append(dbSchedule.Build)

        Return stb.ToString
    End Function

    Sub PostMessage(ByVal sMessage As String)
        Me.divToUpdate.Add("message", sMessage)
        Me.pageCommands.Add("starttimer", "")
        TimerEnabled = True
    End Sub

End Class

