﻿Imports HomeSeerAPI
Imports Scheduler


' Moduel with standard constants, variables and procedures used by indigozest Plug-ins
Module izStd


    ' Added by Nicolai
    Friend Const IniFileName As String = IFACE_NAME & ".ini"
    Friend Const IniSection As String = "SETTINGS" ' Generic ini section for "stuff"

    Friend _DebugLevel As Byte = 0 ' Debug level, default is 0. Value contained in .INI file, stored in the generic section
    Friend _ConsoleDebugLevel As Byte = 0 ' Debug level for sending debug messages to the console
    Friend Const DebugLog As String = IFACE_NAME & " DEBUG" ' String used to preceed all DEBUG log messages
    Friend Const ErrorLog As String = IFACE_NAME & " ERROR" ' String used to preceed all ERROR log messages
    Friend Const WarningLog As String = IFACE_NAME & " WARNING" ' String used to preceed all WARNING log messages

#Region "Properties"
    Public Property DebugLevel() As String
        Get
            Dim ReadStr As String = hs.GetINISetting(IniSection, "Debug", "NONE", IniFileName)
            If (ReadStr = "NONE") Then ' ini file settings not initialised
                hs.SaveINISetting(IniSection, "Debug", "0", IniFileName)
                _DebugLevel = 0
            Else
                _DebugLevel = Val(ReadStr)
            End If
            Return _DebugLevel
        End Get
        Set(ByVal value As String)
            _DebugLevel = value
            hs.SaveINISetting(IniSection, "Debug", _DebugLevel.ToString, IniFileName)
        End Set
    End Property
    Public Property ConsoleDebugLevel() As String
        Get
            Dim ReadStr As String = hs.GetINISetting(IniSection, "Console Debug", "NONE", IniFileName)
            If ReadStr = "NONE" Then ' ini file settings not initialised
                hs.SaveINISetting(IniSection, "Console Debug", "0", IniFileName)
                _ConsoleDebugLevel = 0
            Else
                _ConsoleDebugLevel = Val(ReadStr)
            End If
            Return _ConsoleDebugLevel
        End Get
        Set(ByVal value As String)
            _ConsoleDebugLevel = value
            hs.SaveINISetting(IniSection, "Console Debug", _ConsoleDebugLevel.ToString, IniFileName)
        End Set
    End Property
#End Region
#Region "Init, Shutdown and Setup"
    Friend Function IniPlugIn() As String
        Dim DebugTest As String = ""

        Try ' Init INI file and read various variables
            WriteLog(DebugLog, "In izStd.IniPlugIn", 5)

            _DebugLevel = DebugLevel
            _ConsoleDebugLevel = ConsoleDebugLevel

            Return ""
        Catch ex As Exception
            WriteLog(DebugLog, "Exception from IniPlugIn: " & ex.Message, 0)
            Return "Exception from IniPlugIn: " & ex.Message
        End Try

    End Function
    Friend Function AddVSPairs(ByRef Ref As Integer, ByRef Ctrl As ePairStatusControl, ByRef Value As Integer,
                               ByRef Status As String, ByRef Row As Integer, ByRef Col As Integer) As String

        Dim MyVSP As New VSPair(Ctrl)

        MyVSP.PairType = VSVGPairType.SingleValue
        MyVSP.Render_Location.Row = Row
        MyVSP.Render_Location.Column = Col
        MyVSP.Value = Value
        MyVSP.Status = Status
        MyVSP.IncludeValues = False

        MyVSP.Render = Enums.CAPIControlType.Button

        'hs.DeviceVSP_AddPair(Ref, MyVSP)
        If Not hs.DeviceVSP_AddPair(Ref, MyVSP) Then
            WriteLog(ErrorLog, "VSPair could not be added for device, ref: " & Ref.ToString, 0)
            Return "VSPair could not be added for device, ref: " & Ref.ToString
        End If

        Return ""
    End Function
#End Region
#Region "Text Manipulation Functions"
    Friend Function StrToHexString(ByVal ReceiveData As String, Optional ByRef HexOutput As Boolean = True, Optional Delim As String = " ") As String
        Dim i As Integer
        Dim a As String
        
        If HexOutput Then
            a = "(Hex): "
            For i = 0 To ReceiveData.Length - 1
                a += Hex(Asc(ReceiveData(i))) & Delim
            Next
        Else
            a = "ReceiveData (ASCII): "
            For i = 0 To ReceiveData.Length - 1
                a += Asc(ReceiveData(i)) & Delim
            Next
        End If

        StrToHexString = a & " Length: " & ReceiveData.Length

    End Function
    Friend Function StrToByteArray(ByVal InputText As String, Optional NoEnc As Boolean = False) As Byte()
        ' By default the encoding is done as UTF8Encoding for performance reasons
        ' If no encoding is required then specify True for the NoEnc 
        If NoEnc Then
            Dim i As Integer
            Dim TempByteArray(InputText.Length - 1) As Byte
            For i = 0 To InputText.Length - 1
                TempByteArray(i) = Asc(InputText(i))
            Next
            StrToByteArray = TempByteArray
            TempByteArray = Nothing
        Else
            Dim encoding As New System.Text.UTF8Encoding()
            StrToByteArray = encoding.GetBytes(InputText)
        End If
    End Function
    Friend Function BytesToString(ByVal data() As Byte) As String
        BytesToString = ""
        Dim i As Integer
        For i = 0 To data.Length - 1
            BytesToString += Chr(data(i))
        Next
    End Function
#End Region
#Region "Bit Manipulation"
    Private Function GetBit(b As Byte, bitNumber As Integer) As Boolean
        Return (b And (1 << bitNumber)) <> 0
    End Function
    Private Function SetBit(b As Byte, bitnumber As Integer, OnOff As Boolean) As Byte
        Dim mask As Byte
        If OnOff Then ' Set bit ON
            mask = 1 << bitnumber
            SetBit = b Or mask
        Else ' Set to OFF
            mask = 255 - (1 << bitnumber)
            SetBit = b And mask
        End If

    End Function
#End Region
#Region "Debug Items"
    Public Sub WriteLog(ByRef LogType As String, ByRef LogString As String, ByRef MsgLevel As Integer, Optional ByRef IncludeProcName As Boolean = False)
        If LogType = ErrorLog Or IncludeProcName Then
            Dim stackframe As New Diagnostics.StackFrame(1)
            Dim PriorProc As String = stackframe.GetMethod().Name
            LogString = PriorProc & ": " & LogString
        End If
        If MsgLevel <= 1 Then
            hs.WriteLog(LogType, LogString)
        ElseIf _DebugLevel >= MsgLevel Then
            hs.WriteLog(LogType, LogString)
        End If

        'If IO.Directory.Exists(gEXEPath & "\Debug Logs") Then
        '    IO.File.AppendAllText(gEXEPath & "\Debug Logs\" & IFACE_NAME & ".log", Now.ToString & " ~ " & LogString & vbCrLf)
        'ElseIf IO.Directory.Exists(gEXEPath & "\Logs") Then
        '    IO.File.AppendAllText(gEXEPath & "\Logs\" & IFACE_NAME & ".log", Now.ToString & " ~ " & LogString & vbCrLf)
        'Else
        '    IO.File.AppendAllText(gEXEPath & "\" & IFACE_NAME & ".log", Now.ToString & " ~ " & LogString & vbCrLf)
        'End If

        'End If

        If _ConsoleDebugLevel >= MsgLevel Then Console.WriteLine(LogString)
    End Sub
#End Region




    Sub PEDAdd(ByRef PED As clsPlugExtraData, ByVal PEDName As String, ByVal PEDValue As Object)
        Dim ByteObject() As Byte = Nothing
        If PED Is Nothing Then PED = New clsPlugExtraData
        SerializeObject(PEDValue, ByteObject)
        If Not PED.AddNamed(PEDName, ByteObject) Then
            PED.RemoveNamed(PEDName)
            PED.AddNamed(PEDName, ByteObject)
        End If
    End Sub

    Function PEDGet(ByRef PED As clsPlugExtraData, ByVal PEDName As String) As Object
        Dim ByteObject() As Byte
        Dim ReturnValue As New Object
        ByteObject = PED.GetNamed(PEDName)
        If ByteObject Is Nothing Then Return Nothing
        DeSerializeObject(ByteObject, ReturnValue)
        Return ReturnValue
    End Function


    Public Sub RegisterWebPage(ByVal link As String, Optional linktext As String = "", Optional page_title As String = "", Optional Instance As String = "", Optional ConfigLink As Boolean = False)
        Try
            hs.RegisterPage(link, IFACE_NAME, Instance)
            If linktext = "" Then linktext = link
            linktext = linktext.Replace("_", " ")
            If page_title = "" Then page_title = linktext
            Dim wpd As New HomeSeerAPI.WebPageDesc
            wpd.plugInName = IFACE_NAME
            wpd.plugInInstance = Instance
            wpd.link = link
            wpd.linktext = linktext & Instance
            wpd.page_title = page_title & Instance
            callback.RegisterLink(wpd)
            If ConfigLink Then callback.RegisterConfigLink(wpd)
        Catch ex As Exception
            Log(DebugLog, "Error - Registering Web Links: " & ex.Message)
        End Try
    End Sub

End Module
