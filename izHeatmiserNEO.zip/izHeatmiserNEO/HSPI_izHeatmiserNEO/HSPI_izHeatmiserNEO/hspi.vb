﻿Imports HSCF
Imports HomeSeerAPI
Imports Scheduler
Imports HSCF.Communication.ScsServices.Service
Imports System.Reflection
Imports System.Text
Imports System.Web

Public Class HSPI
    Implements IPlugInAPI               ' this API is required for ALL plugins

    Public OurInstanceFriendlyName As String = ""

    'Public pluginpage As WebPage            ' a jquery web page
    'Public pluginTestPage As WebTestPage
    Dim WebPageName As String = "Neo_Web_Pages"

    Dim sConfigPage As String = "Config"
    Dim sStatusPage As String = "Schedules"
    Dim sHelpPage As String = "http://home.indigozest.net/FTP/HomeSeer3/izHeatmiserNEO/izHeatmiserNEO_manual.pdf"

    Dim ConfigPage As web_config
    Dim StatusPage As web_schedules

    Public Shared bShutDown As Boolean = False


#Region "Externally Accessible Methods/Procedures - e.g. Script Commands"
    ' This Sub set the HolidayMode based on a free text format
    'Public Function SetHolidayByStringXX(ByVal Index As Integer, ByRef DateString As String) As Integer
    '    ' Index is the thermostat you want to control based on the root device number
    '    ' DateString is the string in a format that can be interpreted by CDate()
    '    ' The Function returns -1 if there was a general error and 0 if the setting was OK
    '    Try
    '        ' First check that the thermostat on the givne Index actually exists
    '        If Not izDeviceExist(Index, _ROOT) Then
    '            WriteLog(ErrorLog, "There is no Thermostat created on Index: " & Index.ToString, 0)
    '            Return -1
    '        End If

    '        Dim DT As Date = CDate(DateString)
    '        Dim HolYr As UShort = Year(DT)
    '        If HolYr > 99 Then HolYr = HolYr - 2000
    '        Dim HolMon As UShort = Month(DT)
    '        Dim HolDay As UShort = Day(DT)
    '        Dim HolHr As UShort = Hour(DT)
    '        Dim HolMin As UShort = Minute(DT)
    '        '  WIFI_Write(Index, 24, {HolYr, HolMon, HolDay, HolHr, HolMin})
    '        Return 0
    '    Catch ex As Exception
    '        ' UpdateHSDeviceString(Index, _THOLIDAY, 0, "Invalid Date format")
    '        Return -1
    '    End Try

    '    Return 0
    'End Function

#End Region

#Region "Common Interface"

    Public Function Search(ByVal SearchString As String, ByVal RegEx As Boolean) As HomeSeerAPI.SearchReturn() Implements IPlugInAPI.Search
        Return Nothing
    End Function


    ' a custom call to call a specific procedure in the plugin
    Public Function PluginFunction(ByVal proc As String, ByVal parms() As Object) As Object Implements IPlugInAPI.PluginFunction
        Try
            Dim ty As Type = Me.GetType
            Dim mi As MethodInfo = ty.GetMethod(proc)
            If mi Is Nothing Then
                Log("Method " & proc & " does not exist in this plugin.", LogType.LOG_TYPE_ERROR)
                Return Nothing
            End If
            Return (mi.Invoke(Me, parms))
        Catch ex As Exception
            Log("Error in PluginProc: " & ex.Message, LogType.LOG_TYPE_ERROR)
        End Try

        Return Nothing
    End Function

    Public Function PluginPropertyGet(ByVal proc As String, parms() As Object) As Object Implements IPlugInAPI.PluginPropertyGet
        Try
            Dim ty As Type = Me.GetType
            Dim mi As PropertyInfo = ty.GetProperty(proc)
            If mi Is Nothing Then
                Log("Method " & proc & " does not exist in this plugin.", LogType.LOG_TYPE_ERROR)
                Return Nothing
            End If
            Return mi.GetValue(Me, Nothing)
        Catch ex As Exception
            Log("Error in PluginProc: " & ex.Message, LogType.LOG_TYPE_ERROR)
        End Try

        Return Nothing
    End Function

    Public Sub PluginPropertySet(ByVal proc As String, value As Object) Implements IPlugInAPI.PluginPropertySet
        Try
            Dim ty As Type = Me.GetType
            Dim mi As PropertyInfo = ty.GetProperty(proc)
            If mi Is Nothing Then
                Log("Property " & proc & " does not exist in this plugin.", LogType.LOG_TYPE_ERROR)
            End If
            mi.SetValue(Me, value, Nothing)
        Catch ex As Exception
            Log("Error in PluginPropertySet: " & ex.Message, LogType.LOG_TYPE_ERROR)
        End Try
    End Sub


    Public ReadOnly Property Name As String Implements HomeSeerAPI.IPlugInAPI.Name
        Get
            Return IFACE_NAME
        End Get
    End Property

    Public Function Capabilities() As Integer Implements HomeSeerAPI.IPlugInAPI.Capabilities
        Return HomeSeerAPI.Enums.eCapabilities.CA_IO Or HomeSeerAPI.Enums.eCapabilities.CA_Thermostat
    End Function

    ' return 1 for a free plugin
    ' return 2 for a licensed (for pay) plugin
    Public Function AccessLevel() As Integer Implements HomeSeerAPI.IPlugInAPI.AccessLevel
        Return 2
    End Function

    Public ReadOnly Property HSCOMPort As Boolean Implements HomeSeerAPI.IPlugInAPI.HSCOMPort
        Get
            Return False  'We want HS to give us a com port number for accessing the hardware via a serial port
        End Get
    End Property

    Public Function SupportsMultipleInstances() As Boolean Implements HomeSeerAPI.IPlugInAPI.SupportsMultipleInstances
        Return False
    End Function

    Public Function SupportsMultipleInstancesSingleEXE() As Boolean Implements HomeSeerAPI.IPlugInAPI.SupportsMultipleInstancesSingleEXE
        Return False
    End Function

    Public Function InstanceFriendlyName() As String Implements HomeSeerAPI.IPlugInAPI.InstanceFriendlyName
        Return OurInstanceFriendlyName
    End Function


#If PlugDLL Then
    ' These 2 functions for internal use only
    Public Property HSObj As HomeSeerAPI.IHSApplication Implements HomeSeerAPI.IPlugInAPI.HSObj
        Get
            Return hs
        End Get
        Set(value As HomeSeerAPI.IHSApplication)
            hs = value
        End Set
    End Property

    Public Property CallBackObj As HomeSeerAPI.IAppCallbackAPI Implements HomeSeerAPI.IPlugInAPI.CallBackObj
        Get
            Return callback
        End Get
        Set(value As HomeSeerAPI.IAppCallbackAPI)
            callback = value
        End Set
    End Property
#End If

    Public Function InitIO(ByVal port As String) As String Implements HomeSeerAPI.IPlugInAPI.InitIO
        ' Console.WriteLine("InitIO called with parameter port as " & port)

        Dim plugins() As String = hs.GetPluginsList
        gEXEPath = hs.GetAppPath

        Try
            ' Add date check here to exit PlugIn if this is beyond certain date
            ' Use OA formate to avoid issues with different culture settings
            ' Use separate code to calculate this date if it changes:
            'Dim ExpiryDate As New System.DateTime(2014, 11, 30, 0, 0, 0)
            'Dim MyDate As Double
            'MyDate = ExpiryDate.ToOADate()
            'Const ValidUntilDate As Double = 41973 ' Equate to 30/11/2014
            'Dim ValidUntilValue As Date = DateTime.FromOADate(ValidUntilDate)
            ''
            'If Date.Now > ValidUntilValue Then
            '    hs.WriteLog(IFACE_NAME & " Error", "Trial has expired. Please buy the full product")
            '    Return "Trial has expired. Please buy the full product"
            '    Exit Function
            'End If


            If Instance <> "" Then
                ConfigPage = New web_config(sConfigPage & ":" & Instance)
            Else
                ConfigPage = New web_config(sConfigPage)
            End If
            ConfigPage.hspiref = Me


            If Instance <> "" Then
                StatusPage = New web_schedules(sStatusPage & ":" & Instance)
            Else
                StatusPage = New web_schedules(sStatusPage)
            End If
            StatusPage.hspiref = Me

            Dim o As Object = Nothing
            RegisterWebPage(sConfigPage, sConfigPage, sConfigPage, Instance, True)
            RegisterWebPage(sStatusPage, sStatusPage, sStatusPage, Instance)

            ' Register Help Page
            RegisterWebPage(sHelpPage, "Help", , , False)

            ' init a speak proxy
            'callback.RegisterProxySpeakPlug(IFACE_NAME, "")

            hs.WriteLog(IFACE_NAME, "InitIO called, plug-in is being initialized...")

            Dim ReturnVal As String = ""
            ' Read INI settings and initialise standard indigozest functions
            ReturnVal = IniPlugIn()
            If ReturnVal <> "" Then
                WriteLog(ErrorLog, ReturnVal, 0)
                Return ReturnVal
            End If

            ReturnVal = izInit(port)
            If ReturnVal <> "" Then
                WriteLog(ErrorLog, ReturnVal, 0)
                Return ReturnVal
            End If
        Catch ex As Exception
            bShutDown = True
            Return "Error on InitIO: " & ex.Message
        End Try

        bShutDown = False
        Return ""       ' return no error, or an error message

    End Function


    Private configcalls As Integer
    Public Function ConfigDevice(ref As Integer, user As String, userRights As Integer, newDevice As Boolean) As String Implements HomeSeerAPI.IPlugInAPI.ConfigDevice
        Try
            Dim dv As Scheduler.Classes.DeviceClass = Nothing
            dv = hs.GetDeviceByRef(ref)

            Dim DeviceType As String = dv.Device_Type_String(Nothing)
            DeviceType = Right(DeviceType, DeviceType.Length - IFACE_NAME.Length)

            Dim DeviceName As String = dv.Address(Nothing)
            DeviceName = Right(DeviceName, DeviceName.Length - IFACE_NAME.Length - 1)
            DeviceName = Left(DeviceName, InStr(DeviceName, "-") - 1)

            If InStr(DeviceType.ToLower, "root") = 0 Then Return "" ' Nothing to configure on non-root devices

            Dim PED As clsPlugExtraData = dv.PlugExtraData_Get(hs)
            Dim PEDObject As New Object

            Dim ConfigOptions As New clsRootConfigOptions(DeviceName)
            ConfigOptions = PEDGet(PED, PEDName)

            If ConfigOptions Is Nothing Then
                ConfigOptions = New clsRootConfigOptions(DeviceName)
                PEDAdd(PED, PEDName, ConfigOptions)
                dv.PlugExtraData_Set(hs) = PED
            End If

            Dim stb As New StringBuilder
            stb.Append(ConfigPostHeader("Select Config Options"))
            stb.Append(BuildSingleConfigSelector("Wireless battery thermostat (Neo Air)", "Battery", ConfigOptions.AirDevice))
            stb.Append(BuildSingleConfigSelector("Use Floor Temperature Sensor", "FloorTemp", ConfigOptions.UseFloorTempSensor))
            'stb.Append(BuildSingleConfigSelector("Use Remote Temperature Sensor", "AirTemp", ConfigOptions.UseAirTempSensor))
            stb.Append(ConfigPostFooter)
            Return stb.ToString
        Catch ex As Exception
            WriteLog(ErrorLog, ex.Message, 0)
            Return Err.Description
        End Try
        Return ""
    End Function

    Public Function ConfigDevicePost(ref As Integer, data As String, user As String, userRights As Integer) As Enums.ConfigDevicePostReturn Implements HomeSeerAPI.IPlugInAPI.ConfigDevicePost
        Dim parts As Collections.Specialized.NameValueCollection
        parts = HttpUtility.ParseQueryString(data)

        Select Case Left(parts("id"), 4)
            Case "Save"
                Try
                    Dim dv As Scheduler.Classes.DeviceClass = Nothing

                    Dim PED As New clsPlugExtraData
                    Dim ReturnValue As Integer = Enums.ConfigDevicePostReturn.DoneAndCancel
                    Dim PEDObject As New Object

                    dv = hs.GetDeviceByRef(ref)

                    Dim DeviceName As String = dv.Address(Nothing)
                    DeviceName = Right(DeviceName, DeviceName.Length - IFACE_NAME.Length - 1)
                    DeviceName = Left(DeviceName, InStr(DeviceName, "-") - 1)

                    Dim ConfigOptions As New clsRootConfigOptions(DeviceName)
                    ConfigOptions = ExtractConfigOptions(ref, data, DeviceName)
                    PEDAdd(PED, PEDName, ConfigOptions)

                    dv.PlugExtraData_Set(hs) = PED
                    hs.SaveEventsDevices()

                    ' Now run through and delete any devices that are de-selected
                    If ConfigOptions.AirDevice = False Then ' Remove Battery Device
                        Dim Address As String = IFACE_NAME & "-" & DeviceName & _BATTERY
                        Dim RefIdx As Integer = hs.DeviceExistsAddress(Address, False)
                        If RefIdx <> -1 Then hs.DeleteDevice(RefIdx)
                    Else ' Add Battery Device
                        Dim Address As String = IFACE_NAME & "-" & DeviceName & _BATTERY
                        Dim RefIdx As Integer = hs.DeviceExistsAddress(Address, False)
                        If RefIdx = -1 Then
                            CurrentRootDevice = ref
                            CreateBatteryDevice(DeviceName)
                        End If
                    End If

                    If ConfigOptions.UseFloorTempSensor = False Then ' Floor Temperature Device
                        Dim Address As String = IFACE_NAME & "-" & DeviceName & _FLOORTEMPERATURE
                        Dim RefIdx As Integer = hs.DeviceExistsAddress(Address, False)
                        If RefIdx <> -1 Then hs.DeleteDevice(RefIdx)
                    Else ' Add Floor Temperature
                        Dim Address As String = IFACE_NAME & "-" & DeviceName & _FLOORTEMPERATURE
                        Dim RefIdx As Integer = hs.DeviceExistsAddress(Address, False)
                        If RefIdx = -1 Then
                            CurrentRootDevice = ref
                            CreateFloorTemperatureDevice(DeviceName)
                        End If
                    End If

                    Dim CurIdx As Integer = ThermostatConfigOptions.FindIndex(Function(p) p.ThermostatName = DeviceName)
                    If CurIdx <> -1 Then
                        ThermostatConfigOptions.RemoveAt(CurIdx)
                        ThermostatConfigOptions.Insert(CurIdx, ConfigOptions)
                    Else
                        ThermostatConfigOptions.Add(ConfigOptions)
                        ThermostatConfigOptions.Sort(Function(x, y) x.ThermostatName.CompareTo(y.ThermostatName))
                    End If

                    Return Enums.ConfigDevicePostReturn.DoneAndSave
                Catch ex As Exception
                    WriteLog(ErrorLog, "Error saving PED. Messsage: " & Err.Description, 0)
                    Return Enums.ConfigDevicePostReturn.DoneAndCancel
                End Try
            Case "Canc"
                Return Enums.ConfigDevicePostReturn.DoneAndCancel
        End Select

        Return Enums.ConfigDevicePostReturn.DoneAndCancel
    End Function

    ' Web Page Generation - OLD METHODS
    ' ================================================================================================
    Public Function GenPage(ByVal link As String) As String Implements HomeSeerAPI.IPlugInAPI.GenPage
        Return "Generated from GenPage in plugin " & IFACE_NAME
    End Function
    Public Function PagePut(ByVal data As String) As String Implements HomeSeerAPI.IPlugInAPI.PagePut
        Return ""
    End Function
    '================================================================================================

    'Web Page Generation - NEW METHODS
    '================================================================================================
    Public Function GetPagePlugin(ByVal pageName As String, ByVal user As String, ByVal userRights As Integer, ByVal queryString As String) As String Implements HomeSeerAPI.IPlugInAPI.GetPagePlugin
        'If you have more than one web page, use pageName to route it to the proper GetPagePlugin
        Console.WriteLine("GetPagePlugin pageName: " & pageName)
        ' get the correct page
        Select Case pageName
            Case "Config"
                Return (ConfigPage.GetPagePlugin(pageName, user, userRights, queryString))
            Case "Schedules"
                Return (StatusPage.GetPagePlugin(pageName, user, userRights, queryString))
        End Select
        Return "page not registered"
    End Function

    Public Function PostBackProc(ByVal pageName As String, ByVal data As String, ByVal user As String, ByVal userRights As Integer) As String Implements HomeSeerAPI.IPlugInAPI.PostBackProc
        'If you have more than one web page, use pageName to route it to the proper postBackProc
        Select Case pageName
            Case "Config"
                Return ConfigPage.postBackProc(pageName, data, user, userRights)
            Case "Schedules"
                Return StatusPage.postBackProc(pageName, data, user, userRights)
        End Select
        Return ""
    End Function

    ' ================================================================================================

    Public Sub HSEvent(ByVal EventType As Enums.HSEvent, ByVal parms() As Object) Implements HomeSeerAPI.IPlugInAPI.HSEvent
        Console.WriteLine("HSEvent: " & EventType.ToString)
        Select Case EventType
            Case Enums.HSEvent.VALUE_CHANGE
        End Select
    End Sub



    Public Function InterfaceStatus() As HomeSeerAPI.IPlugInAPI.strInterfaceStatus Implements HomeSeerAPI.IPlugInAPI.InterfaceStatus
        Dim es As New IPlugInAPI.strInterfaceStatus
        es.intStatus = IPlugInAPI.enumInterfaceStatus.OK
        Return es
    End Function

    Public Function PollDevice(ByVal dvref As Integer) As IPlugInAPI.PollResultInfo Implements HomeSeerAPI.IPlugInAPI.PollDevice
        Dim Result As Boolean = NeoInfo
    End Function

    Public Function RaisesGenericCallbacks() As Boolean Implements HomeSeerAPI.IPlugInAPI.RaisesGenericCallbacks
        Return False
    End Function

    Public Sub SetIOMulti(colSend As System.Collections.Generic.List(Of HomeSeerAPI.CAPI.CAPIControl)) Implements HomeSeerAPI.IPlugInAPI.SetIOMulti

        Dim CC As CAPIControl
        Dim dv As Scheduler.Classes.DeviceClass = Nothing


        For Each CC In colSend
            dv = hs.GetDeviceByRef(CC.Ref)

            Dim HSAddr As String = dv.Address(Nothing)
            Dim TypeString As String = dv.Device_Type_String(Nothing)
            TypeString = Right(TypeString, Len(TypeString) - Len(IFACE_NAME))
            Dim TStatName As String = Mid(HSAddr, Len(IFACE_NAME) + 2, InStr(Len(IFACE_NAME) + 2, HSAddr, "-") - Len(IFACE_NAME) - 2)
            Dim DeviceValue As Double = hs.DeviceValue(CC.Ref)
            WriteLog(DebugLog, "In SetIOMulti for T-Stat: " & TStatName, 5)

            Select Case TypeString
                Case _TROOT ' Controller Device
                    Select Case CC.ControlValue
                        Case -10 ' Query All Zones
                            Dim Result As Boolean = NeoInfo
                        Case Else
                            ' Unknown button/value
                            WriteLog(izStd.ErrorLog, "Invalid CC.ControlValue: " & CC.ControlValue.ToString & " in SetMulti_IO for device: " & dv.Device_Type_String(Nothing), 0)
                    End Select
                Case _TSETPOINT
                    Select Case CC.ControlValue
                        Case -100 ' Increment
                            NeoSetPoint({TStatName}) = DeviceValue + 1
                            _NeoFirmware = NeoFirmware ' Send a different command as otherwise subsequent identical commands would fail
                        Case -101 ' Decrement
                            NeoSetPoint({TStatName}) = DeviceValue - 1
                            _NeoFirmware = NeoFirmware ' Send a different command as otherwise subsequent identical commands would fail
                        Case 5 To 35 ' Direct value set
                            NeoSetPoint({TStatName}) = CC.ControlValue
                        Case Else
                    End Select
                Case _TAWAY
                    Select Case CC.ControlValue
                        Case 0 ' Away Off
                            AwayMode(TStatName) = False
                        Case 1 ' Away On
                            AwayMode(TStatName) = True
                        Case Else
                    End Select
                Case _TSTANDBY
                    Select Case CC.ControlValue
                        Case 0 ' Off
                            Standby(TStatName) = False
                        Case 1 ' On
                            Standby(TStatName) = True
                        Case Else
                    End Select
                    Dim Result As Boolean = NeoInfo
                Case _TLOCK
                    If CC.ControlValue = -1001 Then
                        Lock(TStatName) = "OFF"
                    Else
                        Lock(TStatName) = CC.ControlString
                    End If
                Case _THOLD
                    Dim UpdStr As String = CC.ControlString
                    If UpdStr <> "" Then
                        Dim HoldHr As UShort = 0
                        Dim HoldMin As UShort = 0
                        Dim ColonDelim As UShort = InStr(UpdStr, ":")
                        If ColonDelim > 0 Then ' Hour delimiter used
                            HoldHr = Val(Left(UpdStr, ColonDelim - 1))
                            HoldMin = Val(Right(UpdStr, Len(UpdStr) - ColonDelim))
                        Else ' No delimiter, minutes only
                            HoldMin = Val(CC.ControlString)
                        End If
                        Dim TotalMins As UShort = HoldHr * 60 + HoldMin
                        Hold(TStatName) = TotalMins
                    Else
                        If CC.ControlValue >= 0 Then ' If CC.ControlValue <= 0 Then
                            Hold(TStatName) = CC.ControlValue * 5  ' -CC.ControlValue * 5
                        End If
                    End If
                Case _THOLDTEMP
                    Select Case CC.ControlValue
                        Case -100 ' Increment
                            'NeoSetPoint({TStatName}) = DeviceValue + 1
                            _NeoFirmware = NeoFirmware ' Send a different command as otherwise subsequent identical commands would fail
                        Case -101 ' Decrement
                            'NeoSetPoint({TStatName}) = DeviceValue - 1
                            _NeoFirmware = NeoFirmware ' Send a different command as otherwise subsequent identical commands would fail
                        Case 5 To 35 ' Direct value set
                            'NeoSetPoint({TStatName}) = CC.ControlValue
                        Case Else
                    End Select
                    'Case _THOLIDAY
                    '    If CC.ControlString <> "" Then ' Value entered
                    '        Dim DateEval As String = CC.ControlString
                    '        Try
                    '            Dim DT As Date = CDate(DateEval)
                    '            Dim HolYr As UShort = Year(DT)
                    '            If HolYr > 99 Then HolYr = HolYr - 2000
                    '            Dim HolMon As UShort = Month(DT)
                    '            Dim HolDay As UShort = Day(DT)
                    '            Dim HolHr As UShort = Hour(DT)
                    '            Dim HolMin As UShort = Minute(DT)
                    '            '     WIFI_Write(TStatIndex, 24, {HolYr, HolMon, HolDay, HolHr, HolMin})
                    '        Catch ex As Exception
                    '            UpdateHSDeviceString(TStatIndex, _THOLIDAY, 0, "Invalid Date format")
                    '        End Try
                    '    Else ' Off pressed
                    '        '  WIFI_Write(TStatIndex, 24, {CC.ControlValue})
                    '    End If
                Case Else
                    ' Unknown device type
                    WriteLog(ErrorLog, "Unknown device type: " & CC.ControlValue.ToString & " in SetMulti_IO for device: " & dv.Device_Type_String(Nothing), 0)
            End Select
        Next

        ' Clear the object
        dv = Nothing
    End Sub

    Public Sub ShutdownIO() Implements HomeSeerAPI.IPlugInAPI.ShutdownIO
        ' do your shutdown stuff here
        hs.SaveEventsDevices()
        izShutdown()
        bShutDown = True ' setting this flag will cause the plugin to disconnect immediately from HomeSeer
    End Sub

    Public Function SupportsConfigDevice() As Boolean Implements HomeSeerAPI.IPlugInAPI.SupportsConfigDevice
        Return True
    End Function

    Public Function SupportsConfigDeviceAll() As Boolean Implements HomeSeerAPI.IPlugInAPI.SupportsConfigDeviceAll
        Return False
    End Function

    Public Function SupportsAddDevice() As Boolean Implements HomeSeerAPI.IPlugInAPI.SupportsAddDevice
        Return False
    End Function


#End Region

#Region "Actions Interface"

    Public Function ActionCount() As Integer Implements HomeSeerAPI.IPlugInAPI.ActionCount
        Return 0
    End Function

    Private mvarActionAdvanced As Boolean
    Public Property ActionAdvancedMode As Boolean Implements HomeSeerAPI.IPlugInAPI.ActionAdvancedMode
        Set(ByVal value As Boolean)
            mvarActionAdvanced = value
        End Set
        Get
            Return mvarActionAdvanced
        End Get
    End Property

    Public Function ActionBuildUI(ByVal sUnique As String, ByVal ActInfo As IPlugInAPI.strTrigActInfo) As String Implements HomeSeerAPI.IPlugInAPI.ActionBuildUI
        Return ""

        'Dim st As New StringBuilder
        'Dim strAction As strAction


        'If ValidAct(ActInfo.TANumber) Then

        '    ' This is a valid action number for the sample plug-in which offers 2 

        '    If ActInfo.TANumber = 1 Then
        '        strAction = GetActs(ActInfo, ActInfo.DataIn)
        '        If strAction.Result AndAlso strAction.WhichAction = eActionType.Weight AndAlso strAction.ActObj IsNot Nothing Then
        '            Dim Act1 As MyAction1EvenTon = Nothing
        '            Act1 = CType(strAction.ActObj, MyAction1EvenTon)
        '            If Act1.SetTo = MyAction1EvenTon.eSetTo.Not_Set Then
        '                ' NOTE: You must add sUnique to the name of your control!
        '                Dim DL As New clsJQuery.jqDropList("Action1TypeList" & sUnique, "Events", True)
        '                DL.AddItem("(Not Set)", "0", True)
        '                DL.AddItem("Round Tonnage", "1", False)
        '                DL.AddItem("Unrounded Tonnage", "2", False)
        '                st.Append("Set Weight Option Mode:" & DL.Build)
        '            Else
        '                Dim CB1 As New clsJQuery.jqCheckBox("Action1Type" & sUnique, "", "Events", True, True)
        '                If Act1.SetTo = MyAction1EvenTon.eSetTo.Rounded Then
        '                    CB1.checked = True
        '                    st.Append("Uncheck to revert to Unrounded weights:")
        '                Else
        '                    CB1.checked = False
        '                    st.Append("Check to change to Rounded weights:")
        '                End If
        '                st.Append(CB1.Build)
        '            End If
        '        End If
        '    End If

        '    If ActInfo.TANumber = 2 Then
        '        Dim DL2 As New clsJQuery.jqDropList("Act2SubActSelect" & sUnique, "Events", True)
        '        If Not ValidSubAct(ActInfo.TANumber, ActInfo.SubTANumber) Then
        '            DL2.AddItem(" ", "-1", True)
        '        End If
        '        If ActInfo.SubTANumber < 3 And ValidSubAct(ActInfo.TANumber, ActInfo.SubTANumber) Then
        '            mvarActionAdvanced = True
        '        End If
        '        If mvarActionAdvanced Then
        '            DL2.AddItem("Action 2 SubAction 1 - Set Voltage to European", "1", CBool(IIf(ActInfo.SubTANumber = 1, True, False)))
        '            DL2.AddItem("Action 2 SubAction 2 - Set Voltage to North American", "2", CBool(IIf(ActInfo.SubTANumber = 2, True, False)))
        '        End If
        '        DL2.AddItem("Action 2 SubAction 3 - Reset Average Voltage", "3", CBool(IIf(ActInfo.SubTANumber = 3, True, False)))
        '        If Not ValidSubAct(ActInfo.TANumber, ActInfo.SubTANumber) Then
        '            st.Append("Choose a Voltage Sub-Action: " & DL2.Build)
        '        Else
        '            st.Append("Change the Voltage Sub-Action: " & DL2.Build)
        '        End If
        '    End If

        'Else

        '    Return "Error, Action number for plug-in " & IFACE_NAME & " was not set."

        'End If

        'Return st.ToString
    End Function

    Public Function ActionConfigured(ByVal ActInfo As IPlugInAPI.strTrigActInfo) As Boolean Implements HomeSeerAPI.IPlugInAPI.ActionConfigured
        Return False
        'Console.WriteLine("ActionConfigured Called")
        'If ValidAct(ActInfo.TANumber) Then
        '    Return ValidSubAct(ActInfo.TANumber, ActInfo.SubTANumber)
        'Else
        '    Return False
        'End If
    End Function

    Public Function ActionReferencesDevice(ByVal ActInfo As IPlugInAPI.strTrigActInfo, ByVal dvRef As Integer) As Boolean Implements HomeSeerAPI.IPlugInAPI.ActionReferencesDevice
        'Console.WriteLine("ActionReferencesDevice Called")
        ''
        '' Actions in the sample plug-in do not reference devices, but for demonstration purposes we will pretend they do, 
        ''   and that ALL actions reference our sample devices.
        ''
        'If dvRef = MyDevice Then Return True
        Return False
    End Function

    Public Function ActionFormatUI(ByVal ActInfo As IPlugInAPI.strTrigActInfo) As String Implements HomeSeerAPI.IPlugInAPI.ActionFormatUI
        Return ""
        'Dim st As New StringBuilder

        'If ValidAct(ActInfo.TANumber) Then
        '    Dim strAction As strAction = Nothing
        '    If ActInfo.TANumber = 1 Then
        '        strAction = GetActs(ActInfo, ActInfo.DataIn)
        '        If strAction.Result AndAlso strAction.WhichAction = eActionType.Weight AndAlso strAction.ActObj IsNot Nothing Then
        '            Dim Act1 As MyAction1EvenTon = Nothing
        '            Act1 = CType(strAction.ActObj, MyAction1EvenTon)
        '            If Act1.SetTo = MyAction1EvenTon.eSetTo.Not_Set Then
        '                st.Append("The Weight Options Action has not been configured yet.")
        '            Else
        '                If Act1.SetTo = MyAction1EvenTon.eSetTo.Rounded Then
        '                    st.Append("Calculated weights will be rounded.")
        '                Else
        '                    st.Append("Calculated weights will not be rounded.")
        '                End If
        '            End If
        '        Else
        '            st.Append("Error, " & IFACE_NAME & " Weight option action was not recovered.")
        '        End If
        '    End If
        '    If ActInfo.TANumber = 2 Then
        '        If Not ValidSubAct(ActInfo.TANumber, ActInfo.SubTANumber) Then
        '            st.Append("The voltage options action has not been configured yet.")
        '        Else
        '            Select Case ActInfo.SubTANumber
        '                Case 1
        '                    st.Append("Voltages will be European (220 @ 50Hz)")
        '                Case 2
        '                    st.Append("Voltages will be North American (110 @ 60Hz)")
        '                Case 3
        '                    st.Append("The average voltage calculation will be reset to zero.")
        '            End Select
        '        End If
        '    End If
        'Else
        '    st.Append("This action for plug-in " & IFACE_NAME & " was not properly set by HomeSeer.")
        'End If
        'Return st.ToString
    End Function

    Public ReadOnly Property ActionName(ByVal ActionNumber As Integer) As String Implements HomeSeerAPI.IPlugInAPI.ActionName
        Get
            'If Not ValidAct(ActionNumber) Then Return ""
            'Select Case ActionNumber
            '    Case 1
            '        Return IFACE_NAME & ": Set Weight Option"
            '    Case 2
            '        Return IFACE_NAME & ": Voltage Actions"
            'End Select
            Return ""
        End Get
    End Property

    Public Function ActionProcessPostUI(ByVal PostData As Collections.Specialized.NameValueCollection,
                                        ByVal ActInfoIN As IPlugInAPI.strTrigActInfo) As IPlugInAPI.strMultiReturn _
                                        Implements HomeSeerAPI.IPlugInAPI.ActionProcessPostUI

        Dim Ret As New HomeSeerAPI.IPlugInAPI.strMultiReturn
        Ret.sResult = ""
        '' We cannot be passed info ByRef from HomeSeer, so turn right around and return this same value so that if we want, 
        ''   we can exit here by returning 'Ret', all ready to go.  If in this procedure we need to change DataOut or TrigInfo,
        ''   we can still do that.
        'Ret.DataOut = ActInfoIN.DataIn
        'Ret.TrigActInfo = ActInfoIN

        'If PostData Is Nothing Then Return Ret
        'If PostData.Count < 1 Then Return Ret
        'Dim st As New System.Text.StringBuilder
        'Dim sKey As String
        'Dim sValue As String
        'Dim e As EventWebControlInfo

        'Dim Act1 As MyAction1EvenTon = Nothing
        'Dim Act2 As MyAction2Euro = Nothing
        'Dim PlugKey As String = ""

        'Try
        '    ' Look for the Action and SubAction selections because if they changed, then 
        '    '   GetTrigs will create a new Action object before the other changes are applied.
        '    For i As Integer = 0 To PostData.Count - 1
        '        sKey = PostData.GetKey(i)
        '        hs.WriteLog(IFACE_NAME & "Debug", sKey & "potatoes!")
        '        sValue = PostData(sKey).Trim
        '        If sKey Is Nothing Then Continue For
        '        If String.IsNullOrEmpty(sKey.Trim) Then Continue For
        '        '       hs.WriteLog(IFACE_NAME & " DEBUG", sKey & "=" & sValue)
        '        If sKey.Trim = "id" Then
        '            e = U_Get_Control_Info(sValue.Trim)
        '        Else
        '            e = U_Get_Control_Info(sKey.Trim)
        '        End If
        '        If e.Decoded Then

        '            If e.TrigActGroup = enumTAG.Group Or e.TrigActGroup = enumTAG.Trigger Then Continue For

        '            If (e.EvRef = ActInfoIN.evRef) Then
        '                Select Case e.Name_or_ID
        '                    Case "Act2SubActSelect"
        '                        Ret.TrigActInfo.SubTANumber = Convert.ToInt32(Val(sValue.Trim))
        '                    Case "Action1TypeList"
        '                        Ret.TrigActInfo.SubTANumber = Convert.ToInt32(Val(sValue.Trim))
        '                    Case "Action1Type"
        '                        Select Case sValue.Trim.ToLower
        '                            Case "checked"
        '                                Ret.TrigActInfo.SubTANumber = 1
        '                            Case "unchecked"
        '                                Ret.TrigActInfo.SubTANumber = 2
        '                        End Select
        '                End Select
        '            End If

        '        End If
        '    Next

        '    ' This uses the event information or the data passed to us to get or create our
        '    '   action object.
        '    Dim strAct As strAction
        '    strAct = GetActs(Ret.TrigActInfo, ActInfoIN.DataIn)
        '    If strAct.Result = False Then
        '        ' The action object was not found AND there is not enough info (ActionNumber)
        '        '   to create a new one, so there is really nothing we can do here!  We will 
        '        '   wipe out the data since it did not lead to recovery of the action object.
        '        Ret.DataOut = Nothing
        '        Ret.sResult = "No action object was created by " & IFACE_NAME & " - not enough information provided."
        '        Return Ret
        '    End If


        '    'Check for a sub-Action change:
        '    If strAct.WhichAction = eActionType.Voltage AndAlso strAct.ActObj IsNot Nothing Then
        '        Try
        '            Act2 = CType(strAct.ActObj, MyAction2Euro)
        '        Catch ex As Exception
        '            Act2 = Nothing
        '        End Try
        '        If Act2 IsNot Nothing Then
        '            If ValidSubAct(Ret.TrigActInfo.TANumber, Ret.TrigActInfo.SubTANumber) Then
        '                Select Case Ret.TrigActInfo.SubTANumber
        '                    Case 1
        '                        Act2.ThisAction = MyAction2Euro.eVAction.SetEuro
        '                    Case 2
        '                        Act2.ThisAction = MyAction2Euro.eVAction.SetNorthAmerica
        '                    Case 3
        '                        Act2.ThisAction = MyAction2Euro.eVAction.ResetAverage
        '                End Select
        '            End If
        '            If Not SerializeObject(Act2, Ret.DataOut) Then
        '                Ret.sResult = IFACE_NAME & " Error, Action type 2 was modified but serialization failed."
        '                Return Ret
        '            End If
        '        End If
        '    ElseIf strAct.WhichAction = eActionType.Weight AndAlso strAct.ActObj IsNot Nothing Then
        '        Try
        '            Act1 = CType(strAct.ActObj, MyAction1EvenTon)
        '        Catch ex As Exception
        '            Act1 = Nothing
        '        End Try
        '        If ValidSubAct(Ret.TrigActInfo.TANumber, Ret.TrigActInfo.SubTANumber) Then
        '            Select Case Ret.TrigActInfo.SubTANumber
        '                Case 1
        '                    Act1.SetTo = MyAction1EvenTon.eSetTo.Rounded
        '                Case 2
        '                    Act1.SetTo = MyAction1EvenTon.eSetTo.Unrounded
        '            End Select
        '        End If
        '        If Act1 IsNot Nothing Then
        '            If Not SerializeObject(Act1, Ret.DataOut) Then
        '                Ret.sResult = IFACE_NAME & " Error, Action type 1 was modified but serialization failed."
        '                Return Ret
        '            End If
        '        End If
        '    End If

        'Catch ex As Exception
        '    Ret.sResult = "ERROR, Exception in Action UI of " & IFACE_NAME & ": " & ex.Message
        '    Return Ret
        'End Try

        ' All OK
        Ret.sResult = ""
        Return Ret


    End Function

    Public Function HandleAction(ByVal ActInfo As IPlugInAPI.strTrigActInfo) As Boolean Implements HomeSeerAPI.IPlugInAPI.HandleAction
        Return False

        'Dim strAction As strAction = Nothing
        'If ValidAct(ActInfo.TANumber) Then

        '    If ActInfo.TANumber = 1 Then
        '        strAction = GetActs(ActInfo, ActInfo.DataIn)
        '        Else
        '            Log("Error, action type 1 (weight options) provided to Handle Action, but Action ID " & ActInfo.UID.ToString & " could not be recovered.", LogType.LOG_TYPE_ERROR)
        '            Return False
        '        End If
        '    End If
        'Return False
    End Function

#End Region

#Region "Trigger Interface"

    ''' <summary>
    ''' Indicates (when True) that the Trigger is in Condition mode - it is for triggers that can also operate as a condition
    '''    or for allowing Conditions to appear when a condition is being added to an event.
    ''' </summary>
    ''' <param name="TrigInfo">The event, group, and trigger info for this particular instance.</param>
    ''' <value></value>
    ''' <returns>The current state of the Condition flag.</returns>
    ''' <remarks></remarks>
    Public Property Condition(ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As Boolean Implements HomeSeerAPI.IPlugInAPI.Condition
        Get
            'Dim strRET As strTrigger
            'Dim Trig1 As MyTrigger1Ton = Nothing
            'Dim Trig2 As MyTrigger2Shoe = Nothing
            'strRET = GetTrigs(TrigInfo, TrigInfo.DataIn)
            'If strRET.WhichTrigger <> eTriggerType.Unknown Then
            '    If strRET.WhichTrigger = eTriggerType.OneTon Then
            '        Return False    ' Trigger 1 cannot have a condition
            '    ElseIf strRET.WhichTrigger = eTriggerType.TwoVolts Then
            '        Trig2 = CType(strRET.TrigObj, MyTrigger2Shoe)
            '        If Trig2 IsNot Nothing Then
            '            Return Trig2.Condition
            '        End If
            '    End If
            'End If
            Return False
        End Get
        Set(ByVal value As Boolean)
            'Dim strRET As strTrigger
            'Dim Trig1 As MyTrigger1Ton = Nothing
            'Dim Trig2 As MyTrigger2Shoe = Nothing
            'strRET = GetTrigs(TrigInfo, TrigInfo.DataIn)
            'If strRET.WhichTrigger <> eTriggerType.Unknown Then
            '    If strRET.WhichTrigger = eTriggerType.OneTon Then
            '        ' Trigger 1 cannot have a condition
            '        Exit Property
            '    ElseIf strRET.WhichTrigger = eTriggerType.TwoVolts Then
            '        Trig2 = CType(strRET.TrigObj, MyTrigger2Shoe)
            '        If Trig2 IsNot Nothing Then
            '            Trig2.Condition = value
            '        End If
            '    End If
            'End If
        End Set
    End Property

    Public ReadOnly Property HasConditions(ByVal TriggerNumber As Integer) As Boolean Implements HomeSeerAPI.IPlugInAPI.HasConditions
        Get
            Return False
            'Select Case TriggerNumber
            '    Case 1
            '        Return False
            '    Case 2
            '        Return True
            '    Case Else
            '        Return False
            'End Select
        End Get
    End Property

    Public ReadOnly Property HasTriggers() As Boolean Implements HomeSeerAPI.IPlugInAPI.HasTriggers
        Get
            Return False
        End Get
    End Property

    Public ReadOnly Property TriggerCount As Integer Implements HomeSeerAPI.IPlugInAPI.TriggerCount
        Get
            Return 0
        End Get
    End Property

    Public ReadOnly Property TriggerName(ByVal TriggerNumber As Integer) As String Implements HomeSeerAPI.IPlugInAPI.TriggerName
        Get
            Return ""
            'Select Case TriggerNumber
            '    Case 1
            '        Return "Trigger 1 Weighs A Ton"
            '    Case 2
            '        Return "Trigger 2 Voltage for You"
            '    Case Else
            '        Return ""
            'End Select
        End Get
    End Property

    Public ReadOnly Property SubTriggerCount(ByVal TriggerNumber As Integer) As Integer Implements HomeSeerAPI.IPlugInAPI.SubTriggerCount
        Get
            If TriggerNumber = 2 Then
                Return 2
            Else
                Return 0
            End If
        End Get
    End Property

    Public ReadOnly Property SubTriggerName(ByVal TriggerNumber As Integer, ByVal SubTriggerNumber As Integer) As String Implements HomeSeerAPI.IPlugInAPI.SubTriggerName
        Get
            Return ""
            'If TriggerNumber <> 2 Then Return ""
            'Select Case SubTriggerNumber
            '    Case 1
            '        Return "Trig 2 SubTrig 1 - Voltage"
            '    Case 2
            '        Return "Trig 2 SubTrig 2 - Average Voltage"
            '    Case Else
            '        Return ""
            'End Select
        End Get
    End Property

    Public Function TriggerBuildUI(ByVal sUnique As String, ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As String Implements HomeSeerAPI.IPlugInAPI.TriggerBuildUI
        Return ""

        'Dim st As New StringBuilder
        'Dim strTrigger As strTrigger


        'If ValidTrig(TrigInfo.TANumber) Then

        '    ' This is a valid trigger number for the sample plug-in which offers 2 triggers (1 and 2)

        '    If TrigInfo.TANumber = 1 Then
        '        strTrigger = GetTrigs(TrigInfo, TrigInfo.DataIn)
        '        If strTrigger.Result AndAlso strTrigger.WhichTrigger = eTriggerType.OneTon AndAlso strTrigger.TrigObj IsNot Nothing Then
        '            Dim Trig1 As MyTrigger1Ton = Nothing
        '            Trig1 = CType(strTrigger.TrigObj, MyTrigger1Ton)
        '            If Trig1 IsNot Nothing Then
        '                If Trig1.Condition Then
        '                    ' This trigger is not valid for a Condition
        '                Else
        '                    Dim TB As New clsJQuery.jqTextBox("TriggerWeight" & sUnique, "number", Trig1.TriggerWeight.ToString, "Events", 8, True)
        '                    st.Append("&nbsp;&nbsp;")
        '                    st.Append("Enter weight to be exceeded to trigger: " & TB.Build)
        '                End If
        '            End If
        '        End If
        '    End If

        '    If TrigInfo.TANumber = 2 Then
        '        Dim strRET As strTrigger
        '        Dim Trig2 As MyTrigger2Shoe = Nothing
        '        strRET = GetTrigs(TrigInfo, TrigInfo.DataIn)
        '        If strRET.WhichTrigger = eTriggerType.TwoVolts Then
        '            Trig2 = CType(strRET.TrigObj, MyTrigger2Shoe)

        '            If TrigInfo.SubTANumber = 1 Then
        '                ' Voltage
        '                Trig2.SubTrigger2 = False
        '                Dim TB1 As New clsJQuery.jqTextBox("TriggerVolt" & sUnique, "number", Trig2.TriggerValue.ToString, "Events", 8, True)
        '                st.Append("<br>")
        '                If Trig2.Condition Then
        '                    st.Append("Enter the instantaneous voltage (+/- 5V) for the condition to be true: " & TB1.Build)
        '                Else
        '                    st.Append("Enter the instantaneous voltage (exact) for trigger: " & TB1.Build)
        '                End If
        '            ElseIf TrigInfo.SubTANumber = 2 Then
        '                ' Average Voltage
        '                Trig2.SubTrigger2 = True
        '                Dim TB1 As New clsJQuery.jqTextBox("TriggerAvgVolt" & sUnique, "number", Trig2.TriggerValue.ToString, "Events", 8, True)
        '                st.Append("<br>")
        '                If Trig2.Condition Then
        '                    st.Append("Enter the average voltage (+/- 10V) for the condition to be true: " & TB1.Build)
        '                Else
        '                    st.Append("Enter the average voltage (exact) for trigger: " & TB1.Build)
        '                End If

        '            End If
        '        End If

        '    End If


        'Else

        '    Return "Error, Trigger number for plug-in " & IFACE_NAME & " was not set."

        'End If

        'Return st.ToString

    End Function

    Public ReadOnly Property TriggerConfigured(ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As Boolean Implements HomeSeerAPI.IPlugInAPI.TriggerConfigured
        Get
            'Dim strRET As strTrigger
            'Dim Trig1 As MyTrigger1Ton = Nothing
            'Dim Trig2 As MyTrigger2Shoe = Nothing
            'strRET = GetTrigs(TrigInfo, TrigInfo.DataIn)
            'If strRET.WhichTrigger <> eTriggerType.Unknown Then
            '    If strRET.WhichTrigger = eTriggerType.OneTon Then
            '        Try
            '            Trig1 = CType(strRET.TrigObj, MyTrigger1Ton)
            '        Catch ex As Exception
            '            Trig1 = Nothing
            '        End Try
            '        If Trig1 IsNot Nothing Then
            '            If Trig1.TriggerWeight > 0 Then Return True
            '        End If
            '        Return False
            '    ElseIf strRET.WhichTrigger = eTriggerType.TwoVolts Then
            '        Try
            '            Trig2 = CType(strRET.TrigObj, MyTrigger2Shoe)
            '        Catch ex As Exception
            '            Trig2 = Nothing
            '        End Try
            '        If Trig2 IsNot Nothing Then
            '            If Trig2.TriggerValue > 0 Then Return True
            '        End If
            '        Return False
            '    End If
            'End If
            Return False
        End Get
    End Property

    Public Function TriggerReferencesDevice(ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo, ByVal dvRef As Integer) As Boolean Implements HomeSeerAPI.IPlugInAPI.TriggerReferencesDevice
        '
        ' Triggers in the sample plug-in do not reference devices, but for demonstration purposes we will pretend they do, 
        '   and that ALL triggers reference our sample devices.
        '
        ' If dvRef = MyDevice Then Return True
        Return False
    End Function

    Public Function TriggerFormatUI(ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As String Implements HomeSeerAPI.IPlugInAPI.TriggerFormatUI
        'Dim strRET As strTrigger
        'Dim Trig1 As MyTrigger1Ton = Nothing
        'Dim Trig2 As MyTrigger2Shoe = Nothing
        'strRET = GetTrigs(TrigInfo, TrigInfo.DataIn)
        'If strRET.WhichTrigger <> eTriggerType.Unknown Then
        '    If strRET.WhichTrigger = eTriggerType.OneTon Then
        '        Try
        '            Trig1 = CType(strRET.TrigObj, MyTrigger1Ton)
        '        Catch ex As Exception
        '            Trig1 = Nothing
        '        End Try
        '        If Trig1 IsNot Nothing Then
        '            If Trig1.Condition Then Return ""
        '            Return "The weight exceeds " & Trig1.TriggerWeight.ToString & "lbs."
        '        Else
        '            Return "ERROR (A) - Trigger 1 is not properly built yet."
        '        End If
        '    ElseIf strRET.WhichTrigger = eTriggerType.TwoVolts Then
        '        Try
        '            Trig2 = CType(strRET.TrigObj, MyTrigger2Shoe)
        '        Catch ex As Exception
        '            Trig2 = Nothing
        '        End Try
        '        If Trig2 IsNot Nothing Then
        '            If Trig2.SubTrigger2 Then
        '                Dim sRet As String = "The average voltage "
        '                If Trig2.Condition Then
        '                    sRet &= "is within 10V of " & Trig2.TriggerValue.ToString & "V"
        '                    Return sRet
        '                Else
        '                    sRet &= "is " & Trig2.TriggerValue.ToString & "V"
        '                    Return sRet
        '                End If
        '            Else
        '                Dim sRet As String = "The current voltage "
        '                If Trig2.Condition Then
        '                    sRet &= "is within 5V of " & Trig2.TriggerValue.ToString & "V"
        '                    Return sRet
        '                Else
        '                    sRet &= "is " & Trig2.TriggerValue.ToString & "V"
        '                    Return sRet
        '                End If
        '            End If
        '        Else
        '            Return "ERROR (B) - Trigger 2 is not properly built yet."
        '        End If
        '    End If
        'End If
        Return "ERROR - The trigger is not properly built yet."
    End Function

    Public Function TriggerProcessPostUI(ByVal PostData As System.Collections.Specialized.NameValueCollection,
                                         ByVal TrigInfoIn As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As HomeSeerAPI.IPlugInAPI.strMultiReturn Implements HomeSeerAPI.IPlugInAPI.TriggerProcessPostUI

        Dim Ret As New HomeSeerAPI.IPlugInAPI.strMultiReturn
        'Ret.sResult = ""
        '' We cannot be passed info ByRef from HomeSeer, so turn right around and return this same value so that if we want, 
        ''   we can exit here by returning 'Ret', all ready to go.  If in this procedure we need to change DataOut or TrigInfo,
        ''   we can still do that.
        'Ret.DataOut = TrigInfoIn.DataIn
        'Ret.TrigActInfo = TrigInfoIn

        'If PostData Is Nothing Then Return Ret
        'If PostData.Count < 1 Then Return Ret
        'Dim st As New System.Text.StringBuilder
        'Dim sKey As String
        'Dim sValue As String
        'Dim e As EventWebControlInfo

        'Dim Trig1 As MyTrigger1Ton = Nothing
        'Dim Trig2 As MyTrigger2Shoe = Nothing
        'Dim PlugKey As String = ""

        'Try

        '    ' This uses the event information or the data passed to us to get or create our
        '    '   trigger object.
        '    Dim strTrig As strTrigger
        '    strTrig = GetTrigs(Ret.TrigActInfo, TrigInfoIn.DataIn)
        '    If strTrig.Result = False Then
        '        ' The trigger object was not found AND there is not enough info (TriggerNumber)
        '        '   to create a new one, so there is really nothing we can do here!  We will 
        '        '   wipe out the data since it did not lead to recovery of the trigger object.
        '        Ret.DataOut = Nothing
        '        Ret.sResult = "No trigger object was created by " & IFACE_NAME & " - not enough information provided."
        '        Return Ret
        '    End If

        '    ' Now go through the data to see what specifics about the trigger may have been set.
        '    For i As Integer = 0 To PostData.Count - 1
        '        sKey = PostData.GetKey(i)
        '        sValue = PostData(sKey).Trim
        '        If sKey Is Nothing Then Continue For
        '        If String.IsNullOrEmpty(sKey.Trim) Then Continue For
        '        If sKey.Trim = "id" Then
        '            e = U_Get_Control_Info(sValue.Trim)
        '        Else
        '            e = U_Get_Control_Info(sKey.Trim)
        '        End If
        '        If e.Decoded Then

        '            If e.TrigActGroup = enumTAG.Group Or e.TrigActGroup = enumTAG.Action Then Continue For

        '            If (e.EvRef = TrigInfoIn.evRef) Then
        '                Select Case e.Name_or_ID
        '                    'Case "SubtriggerSelect"

        '                    Case "TriggerWeight"
        '                        If strTrig.WhichTrigger = eTriggerType.OneTon AndAlso strTrig.TrigObj IsNot Nothing Then
        '                            Try
        '                                Trig1 = CType(strTrig.TrigObj, MyTrigger1Ton)
        '                            Catch ex As Exception
        '                                Ret.sResult = IFACE_NAME & " Error, Conversion of object to Trigger 1 failed: " & ex.Message
        '                                Return Ret
        '                            End Try
        '                            If Trig1 IsNot Nothing Then
        '                                Trig1.TriggerWeight = Val(sValue.Trim)
        '                            End If
        '                        End If

        '                    Case "TriggerVolt"
        '                        If strTrig.WhichTrigger = eTriggerType.TwoVolts AndAlso strTrig.TrigObj IsNot Nothing Then
        '                            Try
        '                                Trig2 = CType(strTrig.TrigObj, MyTrigger2Shoe)
        '                            Catch ex As Exception
        '                                Ret.sResult = IFACE_NAME & " Error, Conversion of object to Trigger 2 failed: " & ex.Message
        '                                Return Ret
        '                            End Try
        '                            If Trig2 IsNot Nothing Then
        '                                Trig2.TriggerValue = Val(sValue.Trim)
        '                            End If
        '                        End If

        '                    Case "TriggerAvgVolt"
        '                        If strTrig.WhichTrigger = eTriggerType.TwoVolts AndAlso strTrig.TrigObj IsNot Nothing Then
        '                            Try
        '                                Trig2 = CType(strTrig.TrigObj, MyTrigger2Shoe)
        '                            Catch ex As Exception
        '                                Ret.sResult = IFACE_NAME & " Error, Conversion of object to Trigger 2 failed: " & ex.Message
        '                                Return Ret
        '                            End Try
        '                            If Trig2 IsNot Nothing Then
        '                                Trig2.TriggerValue = Val(sValue.Trim)
        '                            End If
        '                        End If

        '                    Case Else
        '                        hs.WriteLog(IFACE_NAME & " Warning", "MyPostData got unhandled key/value of " & e.Name_or_ID & "=" & sValue)
        '                End Select
        '            End If

        '        End If
        '    Next


        '    'Check for a sub-Trigger change:
        '    If strTrig.WhichTrigger = eTriggerType.TwoVolts AndAlso strTrig.TrigObj IsNot Nothing Then
        '        Try
        '            Trig2 = CType(strTrig.TrigObj, MyTrigger2Shoe)
        '        Catch ex As Exception
        '            Trig2 = Nothing
        '        End Try
        '        If Trig2 IsNot Nothing Then
        '            If ValidSubTrig(Ret.TrigActInfo.TANumber, Ret.TrigActInfo.SubTANumber) Then
        '                If Ret.TrigActInfo.SubTANumber = 2 Then
        '                    Trig2.SubTrigger2 = True
        '                End If
        '            End If
        '            If Not SerializeObject(Trig2, Ret.DataOut) Then
        '                Ret.sResult = IFACE_NAME & " Error, Trigger type 2 was modified but serialization failed."
        '                Return Ret
        '            End If
        '        End If
        '    ElseIf strTrig.WhichTrigger = eTriggerType.OneTon AndAlso strTrig.TrigObj IsNot Nothing Then
        '        Try
        '            Trig1 = CType(strTrig.TrigObj, MyTrigger1Ton)
        '        Catch ex As Exception
        '            Trig1 = Nothing
        '        End Try
        '        If Trig1 IsNot Nothing Then
        '            If Not SerializeObject(Trig1, Ret.DataOut) Then
        '                Ret.sResult = IFACE_NAME & " Error, Trigger type 1 was modified but serialization failed."
        '                Return Ret
        '            End If
        '        End If
        '    End If

        'Catch ex As Exception
        '    Ret.sResult = "ERROR, Exception in Trigger UI of " & IFACE_NAME & ": " & ex.Message
        '    Return Ret
        'End Try

        ' All OK
        Ret.sResult = ""
        Return Ret

    End Function

    Public Function TriggerTrue(ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As Boolean Implements IPlugInAPI.TriggerTrue
        ' 
        ' Since plug-ins tell HomeSeer when a trigger is true via TriggerFire, this procedure is called just to check
        '   conditions.
        '
        'Dim strRET As strTrigger
        'Dim Trig1 As MyTrigger1Ton = Nothing
        'Dim Trig2 As MyTrigger2Shoe = Nothing
        'Dim GotIt As Boolean = False
        'Dim WhichOne As eTriggerType = eTriggerType.Unknown

        'If ValidTrigInfo(TrigInfo) Then
        '    strRET = TriggerFromInfo(TrigInfo)
        'End If


        Return False

    End Function

#End Region

    Private Function GetTrigs(ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo, ByRef DataIn() As Byte) As strTrigger
        Dim strRET As strTrigger
        'Dim Trig1 As MyTrigger1Ton = Nothing
        'Dim Trig2 As MyTrigger2Shoe = Nothing

        'Dim GotIt As Boolean = False
        'Dim WhichOne As eTriggerType = eTriggerType.Unknown

        '' ------------------------------------------------------------------------------------------------------------------
        '' ------------------------------------------------------------------------------------------------------------------
        ''
        ''  This procedure recovers or creates a trigger object.  It will first try to find the trigger existing in our
        ''   own collection of trigger objects (colTrig) using the trigger info provided by HomeSeer.  If it cannot find
        ''   the trigger object, then it may just be that since HomeSeer started, that trigger object has not been 
        ''   referenced so that we could add it to our collection; in this case we will create the object from the data
        ''   passed to us from HomeSeer.   If that fails, and we at least have a valid Trigger number, then we will create
        ''   a new trigger object and return it.
        ''
        '' ------------------------------------------------------------------------------------------------------------------
        '' ------------------------------------------------------------------------------------------------------------------


        'If ValidTrigInfo(TrigInfo) Then
        '    strRET = TriggerFromInfo(TrigInfo)
        '    If strRET.WhichTrigger <> eTriggerType.Unknown AndAlso strRET.Result = True Then
        '        If strRET.WhichTrigger = eTriggerType.OneTon Then
        '            Trig1 = strRET.TrigObj
        '            If Trig1 IsNot Nothing Then
        '                strRET = New strTrigger
        '                strRET.TrigObj = Trig1
        '                strRET.WhichTrigger = eTriggerType.OneTon
        '                strRET.Result = True
        '                Return strRET
        '            End If
        '        ElseIf strRET.WhichTrigger = eTriggerType.TwoVolts Then
        '            Trig2 = strRET.TrigObj
        '            If Trig2 IsNot Nothing Then
        '                Trig2.SubTrigger2 = IIf(TrigInfo.SubTANumber = 2, True, False)
        '                strRET = New strTrigger
        '                strRET.TrigObj = Trig2
        '                strRET.WhichTrigger = eTriggerType.TwoVolts
        '                strRET.Result = True
        '                Return strRET
        '            End If
        '        End If
        '    End If
        'End If

        'If ((Not GotIt) Or (WhichOne = eTriggerType.Unknown)) Then
        '    If DataIn IsNot Nothing AndAlso DataIn.Length > 20 Then
        '        ' Try from the data.
        '        strRET = TriggerFromData(DataIn)
        '        If strRET.WhichTrigger <> eTriggerType.Unknown AndAlso strRET.Result = True Then
        '            If strRET.WhichTrigger = eTriggerType.OneTon Then
        '                Trig1 = strRET.TrigObj
        '                If Trig1 IsNot Nothing Then
        '                    If Trig1 IsNot Nothing Then
        '                        strRET = New strTrigger
        '                        strRET.TrigObj = Trig1
        '                        strRET.WhichTrigger = eTriggerType.OneTon
        '                        strRET.Result = True
        '                        Return strRET
        '                    End If
        '                End If
        '            ElseIf strRET.WhichTrigger = eTriggerType.TwoVolts Then
        '                Trig2 = strRET.TrigObj
        '                If Trig2 IsNot Nothing Then
        '                    Trig2.SubTrigger2 = IIf(TrigInfo.SubTANumber = 2, True, False)
        '                    strRET = New strTrigger
        '                    strRET.TrigObj = Trig2
        '                    strRET.WhichTrigger = eTriggerType.TwoVolts
        '                    strRET.Result = True
        '                    Return strRET
        '                End If
        '            End If
        '        End If
        '    End If
        'End If

        'If ((Not GotIt) Or (WhichOne = eTriggerType.Unknown)) Then
        '    If ValidTrigInfo(TrigInfo) Then
        '        Dim PlugKey As String = ""
        '        PlugKey = "K" & TrigInfo.UID.ToString
        '        Select Case TrigInfo.TANumber
        '            Case 1
        '                Trig1 = New MyTrigger1Ton
        '                Trig1.TriggerUID = TrigInfo.UID
        '                Try
        '                    Add_Update_Trigger(Trig1)
        '                Catch ex As Exception
        '                    strRET = New strTrigger
        '                    strRET.TrigObj = Trig1
        '                    strRET.WhichTrigger = eTriggerType.OneTon
        '                    strRET.Result = False
        '                    Return strRET
        '                End Try
        '                strRET = New strTrigger
        '                strRET.TrigObj = Trig1
        '                strRET.WhichTrigger = eTriggerType.OneTon
        '                strRET.Result = True
        '                Return strRET
        '            Case 2
        '                Trig2 = New MyTrigger2Shoe
        '                Trig2.TriggerUID = TrigInfo.UID
        '                If TrigInfo.SubTANumber = 2 Then
        '                    Trig2.SubTrigger2 = True
        '                Else
        '                    Trig2.SubTrigger2 = False
        '                End If
        '                Try
        '                    Add_Update_Trigger(Trig2)
        '                Catch ex As Exception
        '                    strRET = New strTrigger
        '                    strRET.TrigObj = Trig2
        '                    strRET.WhichTrigger = eTriggerType.TwoVolts
        '                    strRET.Result = False
        '                    Return strRET
        '                End Try
        '                strRET = New strTrigger
        '                strRET.TrigObj = Trig2
        '                strRET.WhichTrigger = eTriggerType.TwoVolts
        '                strRET.Result = True
        '                Return strRET
        '        End Select
        '        strRET = New strTrigger
        '        strRET.TrigObj = Nothing
        '        strRET.WhichTrigger = eTriggerType.Unknown
        '        strRET.Result = False
        '        Return strRET
        '    ElseIf ValidTrig(TrigInfo.TANumber) Then
        '        Select Case TrigInfo.TANumber
        '            Case 1
        '                Trig1 = New MyTrigger1Ton
        '                Trig1.TriggerUID = TrigInfo.UID
        '                Try
        '                    Add_Update_Trigger(Trig1)
        '                Catch ex As Exception
        '                End Try
        '                strRET = New strTrigger
        '                strRET.TrigObj = Trig1
        '                strRET.WhichTrigger = eTriggerType.OneTon
        '                strRET.Result = True
        '                Return strRET
        '            Case 2
        '                Trig2 = New MyTrigger2Shoe
        '                Trig2.TriggerUID = TrigInfo.UID
        '                Try
        '                    Add_Update_Trigger(Trig2)
        '                Catch ex As Exception
        '                End Try
        '                If TrigInfo.SubTANumber = 2 Then
        '                    Trig2.SubTrigger2 = True
        '                Else
        '                    Trig2.SubTrigger2 = False
        '                End If
        '                strRET = New strTrigger
        '                strRET.TrigObj = Trig2
        '                strRET.WhichTrigger = eTriggerType.TwoVolts
        '                strRET.Result = True
        '                Return strRET
        '        End Select
        '        strRET = New strTrigger
        '        strRET.TrigObj = Nothing
        '        strRET.WhichTrigger = eTriggerType.Unknown
        '        strRET.Result = False
        '        Return strRET
        '    End If
        'End If


        strRET = New strTrigger
        strRET.TrigObj = Nothing
        strRET.WhichTrigger = eTriggerType.Unknown
        strRET.Result = False
        Return strRET

    End Function

    Private Function GetActs(ByVal ActInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo, ByRef DataIn() As Byte) As strAction
        Dim strRET As strAction
        'Dim Act1 As MyAction1EvenTon = Nothing
        'Dim Act2 As MyAction2Euro = Nothing

        'Dim GotIt As Boolean = False
        'Dim WhichOne As eActionType = eActionType.Unknown

        '' ------------------------------------------------------------------------------------------------------------------
        '' ------------------------------------------------------------------------------------------------------------------
        ''
        ''  This procedure recovers or creates an action object.  It will first try to find the action existing in our
        ''   own collection of action objects (colAct) using the action info provided by HomeSeer.  If it cannot find
        ''   the action object, then it may just be that since HomeSeer started, that action object has not been 
        ''   referenced so that we could add it to our collection; in this case we will create the object from the data
        ''   passed to us from HomeSeer.   If that fails, and we at least have a valid Action number, then we will create
        ''   a new action object and return it.
        ''
        '' ------------------------------------------------------------------------------------------------------------------
        '' ------------------------------------------------------------------------------------------------------------------


        'If ValidActInfo(ActInfo) Then
        '    strRET = ActionFromInfo(ActInfo)
        '    If strRET.WhichAction <> eActionType.Unknown AndAlso strRET.Result = True Then
        '        If strRET.WhichAction = eActionType.Weight Then
        '            Act1 = strRET.ActObj
        '            If Act1 IsNot Nothing Then
        '                strRET = New strAction
        '                strRET.ActObj = Act1
        '                strRET.WhichAction = eActionType.Weight
        '                strRET.Result = True
        '                Return strRET
        '            End If
        '        ElseIf strRET.WhichAction = eActionType.Voltage Then
        '            Act2 = strRET.ActObj
        '            If Act2 IsNot Nothing Then
        '                strRET = New strAction
        '                strRET.ActObj = Act2
        '                strRET.WhichAction = eActionType.Voltage
        '                strRET.Result = True
        '                Return strRET
        '            End If
        '        End If
        '    End If
        'End If

        'If ((Not GotIt) Or (WhichOne = eActionType.Unknown)) Then
        '    If DataIn IsNot Nothing AndAlso DataIn.Length > 20 Then
        '        ' Try from the data.
        '        strRET = ActionFromData(DataIn)
        '        If strRET.WhichAction <> eActionType.Unknown AndAlso strRET.Result = True Then
        '            If strRET.WhichAction = eActionType.Weight Then
        '                Act1 = strRET.ActObj
        '                If Act1 IsNot Nothing Then
        '                    If Act1 IsNot Nothing Then
        '                        strRET = New strAction
        '                        strRET.ActObj = Act1
        '                        strRET.WhichAction = eActionType.Weight
        '                        strRET.Result = True
        '                        Return strRET
        '                    End If
        '                End If
        '            ElseIf strRET.WhichAction = eActionType.Voltage Then
        '                Act2 = strRET.ActObj
        '                If Act2 IsNot Nothing Then
        '                    strRET = New strAction
        '                    strRET.ActObj = Act2
        '                    strRET.WhichAction = eActionType.Voltage
        '                    strRET.Result = True
        '                    Return strRET
        '                End If
        '            End If
        '        End If
        '    End If
        'End If

        'If ((Not GotIt) Or (WhichOne = eActionType.Unknown)) Then
        '    If ValidActInfo(ActInfo) Then
        '        Dim PlugKey As String = ""
        '        PlugKey = "K" & ActInfo.UID.ToString
        '        Select Case ActInfo.TANumber
        '            Case 1
        '                Act1 = New MyAction1EvenTon
        '                Act1.ActionUID = ActInfo.UID
        '                Try
        '                    Add_Update_Action(Act1)
        '                Catch ex As Exception
        '                    strRET = New strAction
        '                    strRET.ActObj = Act1
        '                    strRET.WhichAction = eActionType.Weight
        '                    strRET.Result = False
        '                    Return strRET
        '                End Try
        '                strRET = New strAction
        '                strRET.ActObj = Act1
        '                strRET.WhichAction = eActionType.Weight
        '                strRET.Result = True
        '                Return strRET
        '            Case 2
        '                Act2 = New MyAction2Euro
        '                Act2.ActionUID = ActInfo.UID
        '                If ActInfo.SubTANumber = 1 Then
        '                    Act2.ThisAction = MyAction2Euro.eVAction.SetEuro
        '                ElseIf ActInfo.SubTANumber = 2 Then
        '                    Act2.ThisAction = MyAction2Euro.eVAction.SetNorthAmerica
        '                ElseIf ActInfo.SubTANumber = 3 Then
        '                    Act2.ThisAction = MyAction2Euro.eVAction.ResetAverage
        '                End If
        '                Try
        '                    Add_Update_Action(Act2)
        '                Catch ex As Exception
        '                    strRET = New strAction
        '                    strRET.ActObj = Act2
        '                    strRET.WhichAction = eActionType.Voltage
        '                    strRET.Result = False
        '                    Return strRET
        '                End Try
        '                strRET = New strAction
        '                strRET.ActObj = Act2
        '                strRET.WhichAction = eActionType.Voltage
        '                strRET.Result = True
        '                Return strRET
        '        End Select
        '        strRET = New strAction
        '        strRET.ActObj = Nothing
        '        strRET.WhichAction = eActionType.Unknown
        '        strRET.Result = False
        '        Return strRET
        '    ElseIf ValidAct(ActInfo.TANumber) Then
        '        Select Case ActInfo.TANumber
        '            Case 1
        '                Act1 = New MyAction1EvenTon
        '                Act1.ActionUID = ActInfo.UID
        '                Try
        '                    Add_Update_Action(Act1)
        '                Catch ex As Exception
        '                End Try
        '                strRET = New strAction
        '                strRET.ActObj = Act1
        '                strRET.WhichAction = eActionType.Weight
        '                strRET.Result = True
        '                Return strRET
        '            Case 2
        '                Act2 = New MyAction2Euro
        '                Act2.ActionUID = ActInfo.UID
        '                Try
        '                    Add_Update_Action(Act2)
        '                Catch ex As Exception
        '                End Try
        '                If ActInfo.SubTANumber = 1 Then
        '                    Act2.ThisAction = MyAction2Euro.eVAction.SetEuro
        '                ElseIf ActInfo.SubTANumber = 2 Then
        '                    Act2.ThisAction = MyAction2Euro.eVAction.SetNorthAmerica
        '                ElseIf ActInfo.SubTANumber = 3 Then
        '                    Act2.ThisAction = MyAction2Euro.eVAction.ResetAverage
        '                End If
        '                strRET = New strAction
        '                strRET.ActObj = Act2
        '                strRET.WhichAction = eActionType.Voltage
        '                strRET.Result = True
        '                Return strRET
        '        End Select
        '        strRET = New strAction
        '        strRET.ActObj = Nothing
        '        strRET.WhichAction = eActionType.Unknown
        '        strRET.Result = False
        '        Return strRET
        '    End If
        'End If


        strRET = New strAction
        strRET.ActObj = Nothing
        strRET.WhichAction = eActionType.Unknown
        strRET.Result = False
        Return strRET

    End Function

    Public Enum enumTAG
        Unknown = 0
        Trigger = 1
        Action = 2
        Group = 3
    End Enum

    Public Structure EventWebControlInfo
        Public Decoded As Boolean
        Public EventTriggerGroupID As Integer
        Public GroupID As Integer
        Public EvRef As Integer
        Public TriggerORActionID As Integer
        Public Name_or_ID As String
        Public Additional As String
        Public TrigActGroup As enumTAG
    End Structure

    Friend Shared Function U_Get_Control_Info(ByVal sIN As String) As EventWebControlInfo
        Dim e As New EventWebControlInfo
        e.EventTriggerGroupID = -1
        e.GroupID = -1
        e.EvRef = -1
        e.Name_or_ID = ""
        e.TriggerORActionID = -1
        e.Decoded = False
        e.Additional = ""
        e.TrigActGroup = enumTAG.Unknown

        If sIN Is Nothing Then Return e
        If String.IsNullOrEmpty(sIN.Trim) Then Return e
        If Not sIN.Contains("_") Then Return e
        Dim s() As String
        Dim ch(0) As String
        ch(0) = "_"
        s = sIN.Split(ch, StringSplitOptions.None)
        If s Is Nothing Then Return e
        If s.Length < 1 Then Return e
        If s.Length = 1 Then
            e.Name_or_ID = s(0).Trim
            e.Decoded = True
            Return e
        End If
        Dim sTemp As String
        For i As Integer = 0 To s.Length - 1
            If s(i) Is Nothing Then Continue For
            If String.IsNullOrEmpty(s(i).Trim) Then Continue For
            If i = 0 Then
                e.Name_or_ID = s(0).Trim
            Else
                If s(i).Trim = "ID" Then Continue For
                If s(i).Trim.StartsWith("G") Then
                    sTemp = s(i).Substring(1).Trim
                    If IsNumeric(sTemp) Then
                        e.EventTriggerGroupID = Convert.ToInt32(Val(sTemp))
                        e.TrigActGroup = enumTAG.Trigger
                    End If
                ElseIf s(i).Trim.StartsWith("L") Then
                    sTemp = s(i).Substring(1).Trim
                    If IsNumeric(sTemp) Then
                        e.GroupID = Convert.ToInt32(Val(sTemp))
                        e.TrigActGroup = enumTAG.Group
                    End If
                ElseIf s(i).Trim.StartsWith("T") Then
                    sTemp = s(i).Substring(1).Trim
                    If IsNumeric(sTemp) Then
                        e.TriggerORActionID = Convert.ToInt32(Val(sTemp))
                        e.TrigActGroup = enumTAG.Trigger
                    End If
                ElseIf s(i).Trim.StartsWith("A") Then
                    sTemp = s(i).Substring(1).Trim
                    If IsNumeric(sTemp) Then
                        e.TriggerORActionID = Convert.ToInt32(Val(sTemp))
                        e.TrigActGroup = enumTAG.Action
                    End If
                Else
                    If IsNumeric(s(i).Trim) Then
                        e.EvRef = Convert.ToInt32(Val(s(i).Trim))
                    Else
                        If String.IsNullOrEmpty(e.Additional) Then
                            e.Additional = s(i).Trim
                        Else
                            e.Additional &= "_" & s(i).Trim
                        End If
                    End If
                End If
            End If
        Next
        e.Decoded = True
        Return e
    End Function
    Friend Function ValidTrigInfo(ByVal TrigInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As Boolean
        If TrigInfo.evRef > 0 Then
        Else
            Return False
        End If
        If TrigInfo.TANumber > 0 AndAlso TrigInfo.TANumber < 3 Then
            If TrigInfo.TANumber = 1 Then Return True
            If TrigInfo.SubTANumber > 0 AndAlso TrigInfo.SubTANumber < 3 Then Return True
        End If
        Return False
    End Function
    Friend Function ValidActInfo(ByVal ActInfo As HomeSeerAPI.IPlugInAPI.strTrigActInfo) As Boolean
        If ActInfo.evRef > 0 Then
        Else
            Return False
        End If
        If ActInfo.TANumber > 0 AndAlso ActInfo.TANumber < 3 Then
            If ActInfo.TANumber = 1 Then Return True
            If ActInfo.SubTANumber > 0 AndAlso ActInfo.SubTANumber < 4 Then Return True
        End If
        Return False
    End Function
    Friend Function ValidTrig(ByVal TrigIn As Integer) As Boolean
        If TrigIn > 0 AndAlso TrigIn < 3 Then Return True
        Return False
    End Function
    Friend Function ValidAct(ByVal ActIn As Integer) As Boolean
        If ActIn > 0 AndAlso ActIn < 3 Then Return True
        Return False
    End Function
    Friend Function ValidSubTrig(ByVal TrigIn As Integer, ByVal SubTrigIn As Integer) As Boolean
        If TrigIn > 0 AndAlso TrigIn < 3 Then
            If TrigIn = 1 Then Return True
            If SubTrigIn > 0 AndAlso SubTrigIn < 3 Then Return True
        End If
        Return False
    End Function
    Friend Function ValidSubAct(ByVal ActIn As Integer, ByVal SubActIn As Integer) As Boolean
        If ActIn > 0 AndAlso ActIn < 3 Then
            If ActIn = 1 Then
                If SubActIn > 0 AndAlso SubActIn < 3 Then Return True
                Return False
            End If
            If SubActIn > 0 AndAlso SubActIn < 4 Then Return True
        End If
        Return False
    End Function
    Public Sub New()
        MyBase.New()

        ' Create a thread-safe collection by using the .Synchronized wrapper.
        colTrigs_Sync = New System.Collections.SortedList
        colTrigs = System.Collections.SortedList.Synchronized(colTrigs_Sync)

        colActs_Sync = New System.Collections.SortedList
        colActs = System.Collections.SortedList.Synchronized(colActs_Sync)
    End Sub


    ' called if speak proxy is installed
    Public Sub SpeakIn(device As Integer, txt As String, w As Boolean, host As String) Implements HomeSeerAPI.IPlugInAPI.SpeakIn
        Console.WriteLine("Speaking from HomeSeer, txt: " & txt)
        ' speak back
        hs.SpeakProxy(device, txt & " the plugin added this", w, host)
    End Sub

End Class

