﻿Imports System.Text
Imports System.Web
Imports Scheduler

Public Class web_config
    Inherits clsPageBuilder
    Dim TimerEnabled As Boolean
    Public hspiref As HSPI

    Dim sSpeed As String = ""
    Dim sDataBits As String = ""
    Dim sStopBits As String = ""
    Dim sHandShake As String = ""
    Dim sDebugLevel As String = ""
    Dim sConsole As String = ""
    Dim sTStats As String = ""
    Dim sIPAddress As String
    Dim sPoll As String = ""

    Public Sub New(ByVal pagename As String)
        MyBase.New(pagename)
    End Sub

    Public Overrides Function postBackProc(page As String, data As String, user As String, userRights As Integer) As String

        Dim parts As Collections.Specialized.NameValueCollection
        parts = HttpUtility.ParseQueryString(data)

        Select Case parts("id")
            Case "oIPAddress"
                IPAddress = parts("IPAddress").Trim
                _IPAddress = IPAddress
            Case "oDebugLevel"
                DebugLevel = parts("DebugLevel").Trim
                _DebugLevel = DebugLevel
            Case "oConsoleDebug"
                ConsoleDebugLevel = parts("ConsoleDebug").Trim
                _ConsoleDebugLevel = ConsoleDebugLevel
            Case "oPolling"
                If parts("PollingFrequency") <> sPoll Then
                    PollingFrequency = Val(parts("PollingFrequency").Trim)
                    _PollingFrequency = PollingFrequency
                    ThermostatPollingTimer.Stop()
                    If _PollingFrequency > 0 Then
                        Dim NewPoll As Integer = ThermostatPollingTimer.Interval
                        ThermostatPollingTimer.Interval = _PollingFrequency * 1000
                        ThermostatPollingTimer.Start()
                    End If
                End If
            Case "oUpdateDevices"
                Dim ReturnVal As String = UpdateDevices()
                If ReturnVal = "" Then PostMessage("Devices Updated") Else PostMessage(ReturnVal)
            Case Else
        End Select

        Return MyBase.postBackProc(page, data, user, userRights)
    End Function

    'Public Function GetPagePlugin(ByVal pageName As String, ByVal user As String, ByVal userRights As Integer, ByVal queryString As String, instance As String) As String
    Public Function GetPagePlugin(ByVal pageName As String, ByVal user As String, ByVal userRights As Integer, ByVal queryString As String) As String
        Dim stb As New StringBuilder

        Try
            Me.reset()

            ' handle any queries like mode=something
            Dim parts As Collections.Specialized.NameValueCollection = Nothing
            If (queryString <> "") Then
                parts = HttpUtility.ParseQueryString(queryString)
            End If

            stb.Append(hs.GetPageHeader(pageName, "Configuration", "", "", False, False))

            stb.Append(clsPageBuilder.DivStart("pluginpage", ""))

            ' a message area for error messages from jquery ajax postback (optional, only needed if using AJAX calls to get data)
            stb.Append(clsPageBuilder.DivStart("errormessage", "class='errormessage'"))
            stb.Append(clsPageBuilder.DivEnd)

            stb.Append(clsPageBuilder.FormStart("form", "form", "Post"))

            stb.Append(BuildContent)

            stb.Append("<br><br>")
            stb.Append(hs.GetPageFooter(True))

            'stb.Append(clsPageBuilder.FormEnd)
            stb.Append(clsPageBuilder.DivEnd)

            ' add the body html to the page
            Me.AddBody(stb.ToString)

            ' return the full page
            Return Me.BuildPage()

        Catch ex As Exception
            'WriteMon("Error", "Building page: " & ex.Message)
            Return "error - " & Err.Description
        End Try


    End Function

    Function BuildContent() As String
        Dim stb As New StringBuilder

        ' Start the form
        stb.Append(clsPageBuilder.FormStart("form", "form", "Post"))

        sDebugLevel = _DebugLevel.ToString
        sConsole = _ConsoleDebugLevel.ToString
        sPoll = _PollingFrequency.ToString
        sIPAddress = _IPAddress

        ' Debug table
        stb.Append("<br>Debug Level: ")
        Dim tbDebug As New clsJQuery.jqTextBox("DebugLevel", "text", sDebugLevel, PageName, 5, True)
        tbDebug.editable = False
        tbDebug.toolTip = "Determines the level of debugging (0=No debug, 5=Maximum debug messsages)"
        tbDebug.id = "oDebugLevel"
        stb.Append(tbDebug.Build)

        stb.Append("Console Debug Level: ")
        Dim tbConsole As New clsJQuery.jqTextBox("ConsoleDebug", "text", sConsole, PageName, 5, True)
        tbConsole.toolTip = "Determines the level of debugging to the console (0=No debug, 5=Maximum debug messsages)"
        tbConsole.editable = False
        tbConsole.id = "oConsoleDebug"
        stb.Append(tbConsole.Build)

        ' IP Address
        stb.Append("<br><br>IP Address of Heatmiser NEO Hub: ")
        Dim tbIP As New clsJQuery.jqTextBox("IPAddress", "text", sIPAddress, PageName, 10, True)
        tbIP.toolTip = "Sets the IP address of the NEO hub"
        tbIP.editable = False
        tbIP.id = "oIPAddress"
        stb.Append(tbIP.Build)

        ' Polling Frequency
        stb.Append("<br><br>Polling Frequency: ")
        Dim tbPoll As New clsJQuery.jqTextBox("PollingFrequency (secs.)", "text", sPoll, PageName, 5, True)
        tbPoll.editable = False
        tbPoll.id = "oPolling"
        tbPoll.toolTip = "Enter theamounbt of seceonds between each poll of the thermostats"
        stb.Append(tbPoll.Build)

        ' Update devices
        stb.Append("<br><br>Polling Frequency: ")
        Dim btnUpdate As New clsJQuery.jqButton("UpdateDevices", "Update Devices to Latest Version", PageName, True)
        btnUpdate.id = "oUpdateDevices"
        btnUpdate.toolTip = "Click this button to update ALL your izHeatmiser NEO devices to the latest version. Any customisation you have made may be overwritten."
        stb.Append(btnUpdate.Build)

        stb.Append(clsPageBuilder.FormEnd)
        Return stb.ToString
    End Function


    Sub PostMessage(ByVal sMessage As String)
        Me.divToUpdate.Add("message", sMessage)
        Me.pageCommands.Add("starttimer", "")
        TimerEnabled = True
    End Sub

End Class

