﻿Imports HomeSeerAPI
Imports Scheduler
Imports System.Threading
Imports System.Net.Sockets
Imports System.Web.Script.Serialization
Imports Newtonsoft.Json
Imports System.IO
Imports Newtonsoft.Json.Linq
Imports System.Text
Imports System.Web

' Copyright (C) 2014 indigozest Ltd., www.indigozest.co.uk
' Heatmiser Integration Module
' All Rights Reserved
'
' Required on Raspberry PI: 
' sudo apt-get install libmono-system-numerics4.0-cil
' sudo apt-get install libmono-system-xml-linq4.0-cil
'
' To do:
' ------
' Fix NeoFirmware
' Update all JSON commands to use Newtonsoft for coding/decoding

' Revision History
' v3.0.2.3 - Added additional debug info. Fixing error in INFO call
' v3.0.2.2 - Creating function, from config page, to update devices to latest version. Changing battery device value pairs to: 100=Normal, 0=Low Battery
' v3.0.2.1 - Increasing delay to 100msec in INFO read to minimise problems with incomplete packets being received
' v3.0.2.0 - Added support for battery devices, with set up battery/non-battery via PED on root device
' v3.0.1.15 - Added 50msec delay in INFO read to ensure full packets are read
' v3.0.1.14 - No longer updating devices to new version on startup
' v3.0.1.13 - Fixing bug in updating devices (id not remove old VG/VS pairs)
' v3.0.1.12 - Improved debug info when getting errors on INFO command
' v3.0.1.11 - Hold timer selection is now a positive number
' v3.0.1.10 - Next release version with linux support noww
' v3.0.1.9 - Adding update of devices when new version are installed
' v3.0.1.8 - Improved error handling
' v3.0.1.7 - WIP for Linux support
' v3.0.1.6 - Fix to allow setting hold mode from actions
' v3.0.1.5 - Added garbage collector to free up unused memory
' v3.0.1.4 - Fixing issue to support larger zone systems (tested with 17 zones)
' v3.0.1.3 - Minor updates
' v3.0.1.2 - Moving Newtonsoft DLL to separate directory
' v3.0.1.1 - Adding more devices per thermostat
' v3.0.1.0 - Setup auto discovery 
' v3.0.0.9 - Fixed buffer size issue
' v3.0.0.8 - Improve status updates to root device
' v3.0.0.7 - Tidy up on web config page
' v3.0.0.6 - Added ability to set IP address of HUB on settings page
' v3.0.0.5 - Fixing logging issues and making it licensed
' v3.0.0.4 - Adding schedule management
' v3.0.0.3 - "Downgrade" .NET to 4 from 4.5'

' Work for future releases:
' -------------------------
' - Transfer all read/writes to the new JSON structure
' - Add/fix Hold Temperature (especially setting it - updating from device already done)
' - Nicer web pages 
' - When hold mode is expired - still showing latest
' - Remove surplus/sample code from plug-in
' - Load schedules via Actions
' - PluginFunction calls
' - Cater for Fahrenheit

Module izHeatmiserNEO
    Friend IniSectionUnit = "Thermostat "
    Friend PEDName As String = IFACE_NAME & "PED"

    Friend ThermostatConfigOptions As New List(Of clsRootConfigOptions)

    Private TempIdenticalCounter As Integer = 0
    Private Const izCR As Char = Chr(&HD) ' Line Return for all lines

    Friend CurrentRootDevice As Integer ' Current ROOT device ref used
    Friend LastDeviceRefUsed As Integer ' Used as a temporary dvRef to capture last device created

    Friend _IPAddress As String
    Friend _TCPPort As Integer = 4242
    Friend _TStatCount As Integer = 0
    Friend _TStatNames() As String
    Friend _NeoFirmware As String

    ' Timer
    Friend WithEvents ThermostatPollingTimer As Timers.Timer
    Friend _PollingFrequency As Integer = 60 * 10 ' Timer in seconds for polling thermostats

    ' Timer for Garbage Collection etc.
    Friend WithEvents GeneralTimer As Timers.Timer
    Private GeneralTimerInterval As Integer = 600

#Region "Device Name Constants"
    ' For addresses
    Friend _ROOT As String = "-ROOT"
    Friend _TEMPERATURE As String = "-TEMPERATURE"
    Friend _SETPOINT As String = "-SETPOINT"
    Friend _AWAY As String = "-AWAY"
    Friend _STANDBY As String = "-STANDBY"
    Friend _LOCK As String = "-LOCK"
    Friend _HOLD As String = "-HOLD"
    Friend _FLOORTEMPERATURE As String = "-FLOOR"
    Friend _HEAT As String = "-HEAT"
    Friend _HOLDTEMP As String = "-HOLDTEMP"
    Friend _BATTERY As String = "-BATTERY"

    ' For names and resolution
    Friend _TROOT As String = " Root"
    Friend _TTEMPERATURE As String = " Temperature"
    Friend _TSETPOINT As String = " SetPoint"
    Friend _TAWAY As String = " Away"
    Friend _TSTANDBY As String = " Standby"
    Friend _TLOCK As String = " Lock"
    Friend _THOLD As String = " Hold"
    Friend _TFLOORTEMPERATURE As String = " Floor"
    Friend _THEAT As String = " Heat"
    Friend _THOLDTEMP As String = " Hold Temperature"
    Friend _TBATTERY As String = " Battery"
#End Region

#Region "Properties"
    Public Property IPAddress As String
        Get
            Dim ReadStr As String = hs.GetINISetting(IniSection, "IP Address", "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, "IP Address", "192.168.1.94", IniFileName)
                Return "192.168.1.94"
            Else
                Return ReadStr
            End If
        End Get
        Set(value As String)
            hs.SaveINISetting(IniSection, "IP Address", value, IniFileName)
        End Set
    End Property
    Public Property PollingFrequency() As UShort
        Get
            Dim ReadStr As String = hs.GetINISetting(IniSection, "Polling Frequency", "NONE", IniFileName)
            If ReadStr = "Polling Frequency" Or Val(ReadStr) = 0 Then
                hs.SaveINISetting(IniSection, "Polling Frequency", "60", IniFileName)
                Return 60
            Else
                Return Val(ReadStr)
            End If
        End Get
        Set(value As UShort)
            hs.SaveINISetting(IniSection, "Polling Frequency", value.ToString, IniFileName)
        End Set
    End Property
    Friend ReadOnly Property CurrentVersion() As String
        Get
            Dim myFileVersionInfo As FileVersionInfo = FileVersionInfo.GetVersionInfo("HSPI_izHeatmiserNEO.exe")
            Return myFileVersionInfo.FileVersion
        End Get
    End Property
    Friend Property LastVersion() As String
        Get
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            Dim ReadStr As String = hs.GetINISetting(IniSection, IniEntryName, "NONE", IniFileName)
            If ReadStr = "NONE" Then
                hs.SaveINISetting(IniSection, IniEntryName, "3.0.0.1", IniFileName)
                Return "3.0.0.1"
            Else
                Return ReadStr
            End If
        End Get
        Set(value As String)
            Dim stackframe As New Diagnostics.StackFrame(0)
            Dim IniEntryName As String = stackframe.GetMethod().Name
            IniEntryName = Right(IniEntryName, IniEntryName.Length - 4)
            hs.SaveINISetting(IniSection, IniEntryName, value.ToString, IniFileName)
        End Set
    End Property
#End Region

#Region "Timer Events"
    Private Sub ThermostatPollingTimer_Elapsed(ByVal sender As Object, ByVal e As System.Timers.ElapsedEventArgs) Handles ThermostatPollingTimer.Elapsed
        Try
            Dim Test As Boolean = NeoInfo
            Thread.Sleep(500)

        Catch ex As Exception
            WriteLog(ErrorLog, "Error in Timer function. Error message: " & ex.Message, 0)
        End Try
    End Sub
    Friend Sub GeneralTimer_Elapsed(ByVal sender As Object, ByVal e As System.Timers.ElapsedEventArgs) Handles GeneralTimer.Elapsed
        ' Usded for general timer based tasks. Runs once per minute
        WriteLog(DebugLog, "Running General Timer", 5)
        GC.Collect()  'Collect garbage from other threads etc.
        WriteLog(DebugLog, "Garbage Collection Complete", 5)
    End Sub
#End Region

#Region "Init and Shutdown"
    Friend Function izInit(ByRef port As String) As String
        Dim ReturnVal As String = ""

        Try
            ' First initialise settings from izStandards
            izStd.IniPlugIn()

            _PollingFrequency = PollingFrequency
            _IPAddress = IPAddress

            'Now check if any devices needs updating
            If LastVersion < CurrentVersion Then
                ReturnVal = UpdateDevices()
                If ReturnVal <> "" Then Return ReturnVal
                LastVersion = CurrentVersion
            End If

            ThermostatConfigOptions = ListAllThermostats()

            Dim Result As Boolean = NeoInfo ' Initial poll of devices

            ' Timer1 checks and polls thermostats
            If _PollingFrequency > 0 Then
                ThermostatPollingTimer = New System.Timers.Timer(1000 * _PollingFrequency)
                ThermostatPollingTimer.Enabled = True
                ThermostatPollingTimer.Start()
            End If

            ' Setup General timer
            GeneralTimer = New System.Timers.Timer(1000 * GeneralTimerInterval)
            GeneralTimer.Enabled = True
            GeneralTimer.Start()

            WriteLog(IFACE_NAME, "Initialised, up and running ...", 0)
        Catch ex As Exception
            WriteLog(DebugLog, "Exception from izInit: " & ex.Message, 0)
            Return "Exception from izInit: " & ex.Message
        End Try

        Return ""
    End Function
    Friend Function izShutdown() As Boolean
        Thread.Sleep(500)
        Return True
    End Function
#End Region

#Region "Device Creation" ' Set up as region only to keep Ini proc neat
    Friend Function UpdateDevices(Optional ByVal TypeToUpdate As String = "") As String
        Dim DeviceTypeString As String = ""
        Dim dvRef As Integer = -1
        Dim dvAdd As String = ""

        Try
            Dim dv As Scheduler.Classes.DeviceClass
            Dim EN As Scheduler.Classes.clsDeviceEnumeration
            EN = hs.GetDeviceEnumerator
            If EN Is Nothing Then
                Return "Error getting Enumerator in izInit"
            End If
            Do
                dv = EN.GetNext
                If dv Is Nothing Then Continue Do
                DeviceTypeString = dv.Device_Type_String(Nothing)
                dvRef = dv.Ref(Nothing)
                dvAdd = dv.Address(Nothing)

                If Left(DeviceTypeString, IFACE_NAME.Length) = IFACE_NAME Then
                    ' One of ours, now process it
                    Dim DeviceType As String = Right(DeviceTypeString, DeviceTypeString.Length - IFACE_NAME.Length)
                    If TypeToUpdate = "" Or TypeToUpdate = DeviceType Then
                        Dim DeviceIndex As Integer = Val(Right(dvAdd, 3))
                        Dim TStatName As String = Left(dvAdd, InStrRev(dvAdd, "-") - 1)
                        TStatName = Right(TStatName, Len(TStatName) - Len(IFACE_NAME) - 1)

                        Select Case DeviceType
                            Case _TROOT
                                WriteLog(DebugLog, "Updating" & DeviceType & "Device to latest version: " & CurrentVersion & " from version: " & LastVersion, 3)
                                CreateRootDevice(TStatName, dvRef)
                            Case _TTEMPERATURE
                                WriteLog(DebugLog, "Updating" & DeviceType & "Device to latest version: " & CurrentVersion & " from version: " & LastVersion, 3)
                                CreateTemperatureDevice(TStatName, dvRef)
                            Case _TSETPOINT
                                WriteLog(DebugLog, "Updating" & DeviceType & "Device to latest version: " & CurrentVersion & " from version: " & LastVersion, 3)
                                CreateSetPointDevice(TStatName, dvRef)
                            Case _TAWAY
                                WriteLog(DebugLog, "Updating" & DeviceType & "Device to latest version: " & CurrentVersion & " from version: " & LastVersion, 3)
                                CreateAwayModeDevice(TStatName, dvRef)
                            Case _TSTANDBY
                                WriteLog(DebugLog, "Updating" & DeviceType & "Device to latest version: " & CurrentVersion & " from version: " & LastVersion, 3)
                                CreateStandbyDevice(TStatName, dvRef)
                            Case _TLOCK
                                WriteLog(DebugLog, "Updating" & DeviceType & "Device to latest version: " & CurrentVersion & " from version: " & LastVersion, 3)
                                CreateLockDevice(TStatName, dvRef)
                            Case _THOLD
                                WriteLog(DebugLog, "Updating" & DeviceType & "Device to latest version: " & CurrentVersion & " from version: " & LastVersion, 3)
                                CreateHoldModeDevice(TStatName, dvRef)
                            Case _TFLOORTEMPERATURE
                                WriteLog(DebugLog, "Updating" & DeviceType & "Device to latest version: " & CurrentVersion & " from version: " & LastVersion, 3)
                                CreateFloorTemperatureDevice(TStatName, dvRef)
                            Case _THEAT
                                WriteLog(DebugLog, "Updating" & DeviceType & "Device to latest version: " & CurrentVersion & " from version: " & LastVersion, 3)
                                CreateHeatDevice(TStatName, dvRef)
                            Case _THOLDTEMP
                                WriteLog(DebugLog, "Updating" & DeviceType & "Device to latest version: " & CurrentVersion & " from version: " & LastVersion, 3)
                                CreateHoldTempDevice(TStatName, dvRef)
                            Case _TBATTERY
                                WriteLog(DebugLog, "Updating" & DeviceType & "Device to latest version: " & CurrentVersion & " from version: " & LastVersion, 3)
                                CreateBatteryDevice(TStatName, dvRef)
                            Case Else
                                WriteLog(DebugLog, "Can't update device type: " & DeviceType, 3)
                        End Select
                    End If
                End If
            Loop Until EN.Finished
        Catch ex As Exception
            WriteLog("Error", "Exception updating device: " & ex.Message, 0)
            Return "Error updating devices to latest version"
        End Try
        Return ""
    End Function
    Friend Function CreateDeviceSet(ByRef TStatName As String) As String
        Console.WriteLine("Creating devices ...")
        Dim RtnMsg As String = ""

        ' Create ROOT Device
        RtnMsg = CreateRootDevice(TStatName)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = CreateTemperatureDevice(TStatName)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = CreateSetPointDevice(TStatName)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = CreateAwayModeDevice(TStatName)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = CreateStandbyDevice(TStatName)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = CreateLockDevice(TStatName)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = CreateHoldModeDevice(TStatName)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = CreateFloorTemperatureDevice(TStatName)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = CreateHeatDevice(TStatName)
        If RtnMsg <> "" Then Return RtnMsg

        ''   RtnMsg = CreateHoldTempDevice(TStatName)
        ''  If RtnMsg <> "" Then Return RtnMsg

        hs.SaveEventsDevices()
        Thread.Sleep(2000) ' Take a break to get devices saved before continuing
        WriteLog(DebugLog, "Devices Set created for Thermostat: " & TStatName.ToString, 5)

        Return ""
    End Function
    Private Function CreateRootDevice(ByRef Idx As String, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = IFACE_NAME & "-" & Idx & _ROOT
        If ExistingDeviceRef = -1 Then
            dv.Name(hs) = IFACE_NAME & _TROOT
            dv.Location(hs) = Idx
            dv.Location2(hs) = IFACE_NAME
        End If
        dv.Device_Type_String(hs) = IFACE_NAME & _TROOT

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Plug_In
        DT.Device_Type = DeviceTypeInfo.eDeviceType_GenericRoot
        DT.Device_SubType_Description = "Root Device"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = False
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        'dv.InterfaceInstance(hs) = _Instance
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "", 2, 1)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -2, "", 2, 2) ' Used for JSON error messages
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1002, "TCP Connection Error", 2, 3)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, 0, "No Errors", 2, 4)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, -10, "Poll", 1, 1)
        If RtnMsg <> "" Then Return RtnMsg

        hs.SetDeviceValueByRef(ref, -1, True)

        dv.Last_Change(hs) = Now

        dv.Relationship(hs) = Enums.eRelationship.Parent_Root
        CurrentRootDevice = ref
        LastDeviceRefUsed = ref

        dv = Nothing

        Return ""
    End Function
    Private Function CreateTemperatureDevice(ByRef Idx As String, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = IFACE_NAME & "-" & Idx & _TEMPERATURE

        If ExistingDeviceRef = -1 Then
            dv.Name(hs) = "Current Temperature"
            dv.Location(hs) = Idx
            dv.Location2(hs) = IFACE_NAME
        End If
        dv.Device_Type_String(hs) = IFACE_NAME & _TTEMPERATURE

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Thermostat
        DT.Device_Type = DeviceTypeInfo.eDeviceType_Thermostat.Temperature
        DT.Device_SubType_Description = LTrim(_TTEMPERATURE)
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        ' dv.InterfaceInstance(hs) = _Instance
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "Unknown", 1, 3)
        If RtnMsg <> "" Then Return RtnMsg

        Dim MyVSP As New VSPair(ePairStatusControl.Status)
        MyVSP.PairType = VSVGPairType.Range
        MyVSP.Render_Location.Row = 1
        MyVSP.Render_Location.Column = 1
        MyVSP.IncludeValues = True
        MyVSP.RangeStart = 0
        MyVSP.RangeEnd = 120
        MyVSP.RangeStatusSuffix = Chr(176) & "C"
        MyVSP.RangeStatusDecimals = 1
        MyVSP.Render = Enums.CAPIControlType.ValuesRange
        hs.DeviceVSP_AddPair(ref, MyVSP)
        If Not hs.DeviceVSP_AddPair(ref, MyVSP) Then
            WriteLog(ErrorLog, "VSPair could not be added for device, ref: " & ref.ToString, 0)
            Return "VSPair could not be added for device, ref: " & ref.ToString
        End If

        hs.SetDeviceValueByRef(ref, -1, False)

        If ExistingDeviceRef = -1 Then
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, CurrentRootDevice)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(CurrentRootDevice)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
            LastDeviceRefUsed = ref
        End If

        dv.Last_Change(hs) = Now

        dv = Nothing
        WriteLog(DebugLog, "Current Temperature device created", 5)
        Return ""
    End Function
    Private Function CreateSetPointDevice(ByRef Idx As String, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = IFACE_NAME & "-" & Idx & _SETPOINT
        If ExistingDeviceRef = -1 Then
            dv.Name(hs) = "Set Point"
            dv.Location(hs) = Idx
            dv.Location2(hs) = IFACE_NAME
        End If
        dv.Device_Type_String(hs) = IFACE_NAME & _TSETPOINT

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Thermostat
        DT.Device_Type = DeviceTypeInfo.eDeviceType_Thermostat.Setpoint
        DT.Device_SubType_Description = LTrim(_TSETPOINT)
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        'dv.InterfaceInstance(hs) = _Instance
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "Unknown", 1, 3)
        If RtnMsg <> "" Then Return RtnMsg

        Dim MyVSP As New VSPair(ePairStatusControl.Both)
        MyVSP.PairType = VSVGPairType.Range
        MyVSP.Render_Location.Row = 1
        MyVSP.Render_Location.Column = 1
        MyVSP.IncludeValues = True
        MyVSP.RangeStart = 5
        MyVSP.RangeEnd = 35
        MyVSP.RangeStatusSuffix = Chr(176) & "C"
        MyVSP.Render = Enums.CAPIControlType.ValuesRange
        MyVSP.ControlUse = ePairControlUse._HeatSetPoint
        hs.DeviceVSP_AddPair(ref, MyVSP)
        If Not hs.DeviceVSP_AddPair(ref, MyVSP) Then
            WriteLog(ErrorLog, "VSPair could not be added for device, ref: " & ref.ToString, 0)
            Return "VSPair could not be added for device, ref: " & ref.ToString
        End If

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, -101, "Decrease", 1, 2)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, -100, "Increase", 1, 3)
        If RtnMsg <> "" Then Return RtnMsg

        hs.SetDeviceValueByRef(ref, -1, False)

        If ExistingDeviceRef = -1 Then
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, CurrentRootDevice)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(CurrentRootDevice)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
            LastDeviceRefUsed = ref
        End If

        dv.Last_Change(hs) = Now

        dv = Nothing
        WriteLog(DebugLog, "SetPoint device created", 5)
        Return ""
    End Function
    Private Function CreateAwayModeDevice(ByRef Idx As String, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = IFACE_NAME & "-" & Idx & _AWAY
        If ExistingDeviceRef = -1 Then
            dv.Name(hs) = "Away Mode"
            dv.Location(hs) = Idx
            dv.Location2(hs) = IFACE_NAME
        End If
        dv.Device_Type_String(hs) = IFACE_NAME & _TAWAY


        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Thermostat
        DT.Device_Type = DeviceTypeInfo.eDeviceType_Thermostat.Operating_Mode
        DT.Device_SubType_Description = "Away Mode"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        'dv.InterfaceInstance(hs) = _Instance
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "Unknown", 1, 3)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, 0, "Away Off", 1, 2)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, 1, "Away On", 1, 1)
        If RtnMsg <> "" Then Return RtnMsg


        hs.SetDeviceValueByRef(ref, -1, True)

        If ExistingDeviceRef = -1 Then
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, CurrentRootDevice)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(CurrentRootDevice)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
            LastDeviceRefUsed = ref
        End If

        dv.Last_Change(hs) = Now

        dv = Nothing
        WriteLog(DebugLog, "Away Mode device created", 5)
        Return ""
    End Function
    Private Function CreateStandbyDevice(ByRef Idx As String, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = IFACE_NAME & "-" & Idx & _STANDBY
        If ExistingDeviceRef = -1 Then
            dv.Name(hs) = "Standby Mode"
            dv.Location(hs) = Idx
            dv.Location2(hs) = IFACE_NAME
        End If
        dv.Device_Type_String(hs) = IFACE_NAME & _TSTANDBY


        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Thermostat
        DT.Device_Type = DeviceTypeInfo.eDeviceType_Thermostat.Operating_Mode
        DT.Device_SubType_Description = "Standby Mode"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        'dv.InterfaceInstance(hs) = _Instance
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "Unknown", 1, 3)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, 0, "Normal", 1, 2)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, 1, "Standby", 1, 1)
        If RtnMsg <> "" Then Return RtnMsg

        hs.SetDeviceValueByRef(ref, -1, True)

        If ExistingDeviceRef = -1 Then
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, CurrentRootDevice)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(CurrentRootDevice)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
            LastDeviceRefUsed = ref
        End If

        dv.Last_Change(hs) = Now

        dv = Nothing
        WriteLog(DebugLog, "Frost Mode device created", 5)
        Return ""
    End Function
    Private Function CreateLockDevice(ByRef Idx As String, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = IFACE_NAME & "-" & Idx & _LOCK
        If ExistingDeviceRef = -1 Then
            dv.Name(hs) = "Lock"
            dv.Location(hs) = Idx
            dv.Location2(hs) = IFACE_NAME
        End If
        dv.Device_Type_String(hs) = IFACE_NAME & _TLOCK


        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Thermostat
        DT.Device_Type = DeviceTypeInfo.eDeviceType_Thermostat.Hold_Mode
        DT.Device_SubType_Description = "Lock"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        'dv.InterfaceInstance(hs) = _Instance
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        Dim MyVSP As New VSPair(ePairStatusControl.Control)
        MyVSP.PairType = VSVGPairType.SingleValue
        MyVSP.Render_Location.Row = 1
        MyVSP.Render_Location.Column = 2
        MyVSP.Render_Location.ColumnSpan = 5
        MyVSP.Render = Enums.CAPIControlType.TextBox_String
        If Not hs.DeviceVSP_AddPair(ref, MyVSP) Then
            WriteLog(ErrorLog, "VSPair could not be added for device, ref: " & ref.ToString, 0)
            Return "VSPair could not be added for device, ref: " & ref.ToString
        End If

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "Unknown", 2, 1)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, -1001, "Unlock", 1, 1)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -2, "Unlocked", 2, 2)
        If RtnMsg <> "" Then Return RtnMsg


        hs.SetDeviceValueByRef(ref, -1, True)

        If ExistingDeviceRef = -1 Then
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, CurrentRootDevice)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(CurrentRootDevice)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
            LastDeviceRefUsed = ref
        End If

        dv.Last_Change(hs) = Now

        dv = Nothing
        WriteLog(DebugLog, "Lock device created", 5)
        Return ""
    End Function
    Private Function CreateHoldModeDevice(ByRef Idx As String, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = IFACE_NAME & "-" & Idx & _HOLD
        If ExistingDeviceRef = -1 Then
            dv.Name(hs) = "Hold Mode"
            dv.Location(hs) = Idx
            dv.Location2(hs) = IFACE_NAME
        End If
        dv.Device_Type_String(hs) = IFACE_NAME & _THOLD

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Thermostat
        DT.Device_Type = DeviceTypeInfo.eDeviceType_Thermostat.Hold_Mode
        DT.Device_SubType_Description = "Hold"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        'dv.InterfaceInstance(hs) = _Instance
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        Dim MyVSP As New VSPair(ePairStatusControl.Control)
        MyVSP.PairType = VSVGPairType.SingleValue
        MyVSP.Render_Location.Row = 1
        MyVSP.Render_Location.Column = 2
        MyVSP.Render_Location.ColumnSpan = 5
        MyVSP.Render = Enums.CAPIControlType.TextBox_String
        If Not hs.DeviceVSP_AddPair(ref, MyVSP) Then
            WriteLog(ErrorLog, "VSPair could not be added for device, ref: " & ref.ToString, 0)
            Return "VSPair could not be added for device, ref: " & ref.ToString
        End If

        'MyVSP = New VSPair(ePairStatusControl.Both)
        'MyVSP.PairType = VSVGPairType.Range
        'MyVSP.Render_Location.Row = 2
        'MyVSP.Render_Location.Column = 1
        'MyVSP.IncludeValues = True
        'MyVSP.RangeStart = 1
        'MyVSP.RangeEnd = 1000
        'MyVSP.RangeStatusSuffix = " mins."
        'MyVSP.Render = Enums.CAPIControlType.ValuesRange
        'hs.DeviceVSP_AddPair(ref, MyVSP)
        'If Not hs.DeviceVSP_AddPair(ref, MyVSP) Then
        '    WriteLog(ErrorLog, "VSPair could not be added for device, ref: " & ref.ToString, 0)
        '    Return "VSPair could not be added for device, ref: " & ref.ToString
        'End If

        MyVSP = New VSPair(ePairStatusControl.Control)
        Dim i As Integer
        For i = 1 To 288
            MyVSP.PairType = VSVGPairType.SingleValue
            MyVSP.Render_Location.Row = 0
            MyVSP.Render_Location.Column = 0
            MyVSP.Render_Location.ColumnSpan = 0
            Dim Value As Integer = i * 5
            MyVSP.Value = i ' -i

            Dim HoldHours As Integer = Value \ 60
            Dim HoldMinutes As Integer = Value - (HoldHours * 60)
            Dim HoldLeft As String = Format(HoldHours, "00") & ":" & Format(HoldMinutes, "00")

            MyVSP.Status = HoldLeft
            MyVSP.IncludeValues = False
            MyVSP.Render = Enums.CAPIControlType.TextList
            hs.DeviceVSP_AddPair(ref, MyVSP)
        Next

        Dim xMyVSP As New VSPair(ePairStatusControl.Control)
        xMyVSP.PairType = VSVGPairType.Range
        xMyVSP.Render_Location.Row = 2
        xMyVSP.Render_Location.Column = 1
        xMyVSP.Render_Location.ColumnSpan = 15
        'MyVSP.IncludeValues = True
        xMyVSP.RangeStart = 1  ' -1
        xMyVSP.RangeEnd = 288   ' -288
        'MyVSP.RangeStatusPrefix = " "
        xMyVSP.Render = Enums.CAPIControlType.ValuesRange
        If Not hs.DeviceVSP_AddPair(ref, xMyVSP) Then
            WriteLog(ErrorLog, "VSPair could not be added for device, ref: " & ref.ToString, 0)
            Return "VSPair could not be added for device, ref: " & ref.ToString
        End If

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "Unknown", 2, 1)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Both, 0, "Off", 1, 1)
        If RtnMsg <> "" Then Return RtnMsg

        hs.SetDeviceValueByRef(ref, -1, True)

        If ExistingDeviceRef = -1 Then
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, CurrentRootDevice)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(CurrentRootDevice)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
            LastDeviceRefUsed = ref
        End If

        dv.Last_Change(hs) = Now

        dv = Nothing
        WriteLog(DebugLog, "Hold Mode device created", 5)
        Return ""
    End Function
    Friend Function CreateFloorTemperatureDevice(ByRef Idx As String, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = IFACE_NAME & "-" & Idx & _FLOORTEMPERATURE
        If ExistingDeviceRef = -1 Then
            dv.Name(hs) = "Current Floor Temperature"
            dv.Location(hs) = Idx
            dv.Location2(hs) = IFACE_NAME
        End If
        dv.Device_Type_String(hs) = IFACE_NAME & _TFLOORTEMPERATURE

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Thermostat
        DT.Device_Type = DeviceTypeInfo.eDeviceType_Thermostat.Temperature
        DT.Device_SubType_Description = LTrim(_TTEMPERATURE)
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        ' dv.InterfaceInstance(hs) = _Instance
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "Unknown", 1, 3)
        If RtnMsg <> "" Then Return RtnMsg

        Dim MyVSP As New VSPair(ePairStatusControl.Status)
        MyVSP.PairType = VSVGPairType.Range
        MyVSP.Render_Location.Row = 1
        MyVSP.Render_Location.Column = 1
        MyVSP.IncludeValues = True
        MyVSP.RangeStart = 0
        MyVSP.RangeEnd = 120
        MyVSP.RangeStatusSuffix = Chr(176) & "C"
        MyVSP.RangeStatusDecimals = 1
        MyVSP.Render = Enums.CAPIControlType.ValuesRange
        hs.DeviceVSP_AddPair(ref, MyVSP)
        If Not hs.DeviceVSP_AddPair(ref, MyVSP) Then
            WriteLog(ErrorLog, "VSPair could not be added for device, ref: " & ref.ToString, 0)
            Return "VSPair could not be added for device, ref: " & ref.ToString
        End If

        hs.SetDeviceValueByRef(ref, -1, False)

        If ExistingDeviceRef = -1 Then
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, CurrentRootDevice)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(CurrentRootDevice)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
            LastDeviceRefUsed = ref
        End If

        dv.Last_Change(hs) = Now
        dv = Nothing
        WriteLog(DebugLog, "Current Floor Temperature device created", 5)
        Return ""
    End Function
    Private Function CreateHeatDevice(ByRef Idx As String, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = IFACE_NAME & "-" & Idx & _HEAT
        If ExistingDeviceRef = -1 Then
            dv.Name(hs) = "Heat Mode"
            dv.Location(hs) = Idx
            dv.Location2(hs) = IFACE_NAME
        End If
        dv.Device_Type_String(hs) = IFACE_NAME & _THEAT

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Thermostat
        DT.Device_Type = DeviceTypeInfo.eDeviceType_Thermostat.Hold_Mode
        DT.Device_SubType_Description = "Heat"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        'dv.InterfaceInstance(hs) = _Instance
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "Unknown", 1, 3)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, 0, "Off", 1, 2)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, 1, "Heat", 1, 1)
        If RtnMsg <> "" Then Return RtnMsg

        hs.SetDeviceValueByRef(ref, -1, True)

        If ExistingDeviceRef = -1 Then
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, CurrentRootDevice)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(CurrentRootDevice)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
            LastDeviceRefUsed = ref
        End If

        dv.Last_Change(hs) = Now

        dv = Nothing
        WriteLog(DebugLog, "Heat device created", 5)
        Return ""
    End Function
    Private Function CreateHoldTempDevice(ByRef Idx As String, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = IFACE_NAME & "-" & Idx & _HOLDTEMP
        If ExistingDeviceRef = -1 Then
            dv.Name(hs) = "Hold Temperature"
            dv.Location(hs) = Idx
            dv.Location2(hs) = IFACE_NAME
        End If
        dv.Device_Type_String(hs) = IFACE_NAME & _THOLDTEMP

        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Thermostat
        DT.Device_Type = DeviceTypeInfo.eDeviceType_Thermostat.Setpoint
        DT.Device_SubType_Description = LTrim(_THOLDTEMP)
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        'dv.InterfaceInstance(hs) = _Instance
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "Unknown", 1, 3)
        If RtnMsg <> "" Then Return RtnMsg

        Dim MyVSP As New VSPair(ePairStatusControl.Both)
        MyVSP.PairType = VSVGPairType.Range
        MyVSP.Render_Location.Row = 1
        MyVSP.Render_Location.Column = 1
        MyVSP.IncludeValues = True
        MyVSP.RangeStart = 5
        MyVSP.RangeEnd = 35
        MyVSP.RangeStatusSuffix = Chr(176) & "C"
        MyVSP.Render = Enums.CAPIControlType.ValuesRange
        hs.DeviceVSP_AddPair(ref, MyVSP)
        If Not hs.DeviceVSP_AddPair(ref, MyVSP) Then
            WriteLog(ErrorLog, "VSPair could not be added for device, ref: " & ref.ToString, 0)
            Return "VSPair could not be added for device, ref: " & ref.ToString
        End If

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, -101, "Decrease", 1, 2)
        If RtnMsg <> "" Then Return RtnMsg

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Control, -100, "Increase", 1, 3)
        If RtnMsg <> "" Then Return RtnMsg

        hs.SetDeviceValueByRef(ref, -1, False)

        If ExistingDeviceRef = -1 Then
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, CurrentRootDevice)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(CurrentRootDevice)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
            LastDeviceRefUsed = ref
        End If

        dv.Last_Change(hs) = Now

        dv = Nothing
        WriteLog(DebugLog, "Hold Temperature device created", 5)
        Return ""
    End Function
    Friend Function CreateBatteryDevice(ByRef Idx As String, Optional ByVal ExistingDeviceRef As Integer = -1) As String
        Dim dv As Scheduler.Classes.DeviceClass = Nothing
        Dim ref As Integer
        Dim RtnMsg As String = ""

        If ExistingDeviceRef <> -1 Then
            ref = ExistingDeviceRef
        Else
            ref = hs.NewDeviceRef(IFACE_NAME)
        End If

        dv = hs.GetDeviceByRef(ref)
        dv.Address(hs) = IFACE_NAME & "-" & Idx & _BATTERY
        If ExistingDeviceRef = -1 Then
            dv.Name(hs) = "Battery"
            dv.Location(hs) = Idx
            dv.Location2(hs) = IFACE_NAME
        End If
        dv.Device_Type_String(hs) = IFACE_NAME & _TBATTERY


        Dim DT As New DeviceTypeInfo
        DT.Device_API = DeviceTypeInfo.eDeviceAPI.Thermostat
        DT.Device_SubType_Description = "Battery"
        dv.DeviceType_Set(hs) = DT

        dv.Status_Support(hs) = True
        dv.Can_Dim(hs) = False
        dv.Interface(hs) = IFACE_NAME
        'dv.InterfaceInstance(hs) = _Instance
        dv.MISC_Set(hs, Enums.dvMISC.SHOW_VALUES)

        hs.DeviceVSP_ClearAll(ref, True)
        hs.DeviceVGP_ClearAll(ref, True)

        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, -1, "Unknown", 1, 3)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, 100, "Normal", 1, 2)
        If RtnMsg <> "" Then Return RtnMsg
        RtnMsg = AddVSPairs(ref, ePairStatusControl.Status, 0, "Low Battery", 1, 1)
        If RtnMsg <> "" Then Return RtnMsg

        Dim GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = 100
        GPair.Graphic = "/images/HomeSeer/status/battery_100.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        GPair = New VGPair
        GPair.PairType = VSVGPairType.SingleValue
        GPair.Set_Value = 0
        GPair.Graphic = "/images/HomeSeer/status/battery_0.png"
        hs.DeviceVGP_AddPair(ref, GPair)

        hs.SetDeviceValueByRef(ref, -1, True)

        If ExistingDeviceRef = -1 Then
            dv.Relationship(hs) = Enums.eRelationship.Child
            dv.AssociatedDevice_Add(hs, CurrentRootDevice)
            Dim RootDev As Scheduler.Classes.DeviceClass = Nothing
            RootDev = hs.GetDeviceByRef(CurrentRootDevice)
            RootDev.AssociatedDevice_Add(hs, ref)
            RootDev = Nothing
            LastDeviceRefUsed = ref
        End If

        dv.Last_Change(hs) = Now

        dv = Nothing
        WriteLog(DebugLog, "Battery device created", 5)
        Return ""
    End Function
#End Region

#Region "Device Update Procedures"
    Function izDeviceExist(ByRef Idx As String, ByRef DevType As String) As Boolean
        Dim DeviceRef As Integer = hs.DeviceExistsAddress(IFACE_NAME & "-" & Idx & DevType, False)
        Return Not (DeviceRef And -1)
    End Function
    Friend Function CreateMissingDevice(ByVal TStatName As String, ByVal DevType As String) As Integer
        If DevType <> _ROOT Then
            ' Look up RootDevice and set CurrentRootDevice for use in device creation
            Dim Device As String = IFACE_NAME & "-" & TStatName & _ROOT
            CurrentRootDevice = hs.DeviceExistsAddress(Device, False)
            If CurrentRootDevice = -1 Then Return -1
            Select Case DevType
                Case _TEMPERATURE
                    CreateTemperatureDevice(TStatName)
                    Return LastDeviceRefUsed
                Case _SETPOINT
                    CreateSetPointDevice(TStatName)
                    Return LastDeviceRefUsed
                Case _AWAY
                    CreateAwayModeDevice(TStatName)
                    Return LastDeviceRefUsed
                Case _STANDBY
                    CreateStandbyDevice(TStatName)
                    Return LastDeviceRefUsed
                Case _LOCK
                    CreateLockDevice(TStatName)
                    Return LastDeviceRefUsed
                Case _HOLD
                    CreateHoldModeDevice(TStatName)
                    Return LastDeviceRefUsed
                Case _FLOORTEMPERATURE
                    CreateFloorTemperatureDevice(TStatName)
                    Return LastDeviceRefUsed
                Case _HEAT
                    CreateHeatDevice(TStatName)
                    Return LastDeviceRefUsed
                Case _HOLDTEMP
                    CreateHoldTempDevice(TStatName)
                    Return LastDeviceRefUsed
                Case Else
                    WriteLog(ErrorLog, "CreateMissingDevice: Unknown device: " & DevType & " for Thermostat: " & TStatName, 0)
                    Return -1
            End Select
        Else
            CreateDeviceSet(TStatName)
            Return CurrentRootDevice
        End If
    End Function
    Friend Sub UpdateHSDeviceValue(ByRef TStatName As String, ByRef DevType As String, ByRef Val As Double)
        Dim Device As String = IFACE_NAME & "-" & TStatName & DevType
        Dim DeviceRef As Integer = hs.DeviceExistsAddress(Device, False)

        If DeviceRef = -1 Then
            DeviceRef = CreateMissingDevice(TStatName, DevType) ' Device does not exist, create device
        End If

        If DeviceRef <> -1 Then
            hs.SetDeviceValueByRef(DeviceRef, Val, True)
            hs.SetDeviceLastChange(DeviceRef, Now())
            WriteLog(DebugLog, "Device: " & Device & " updated", 5)
            Device = IFACE_NAME & "-" & TStatName & _ROOT
            DeviceRef = hs.DeviceExistsAddress(Device, False)
            If hs.DeviceValue(DeviceRef) = -2 Then hs.SetDeviceValueByRef(DeviceRef, 0, False)
        Else
            WriteLog(DebugLog, "Can't update Device: " & Device & " as this device does not exist", 5)
        End If
    End Sub
    Friend Sub UpdateHSDeviceString(ByRef TStatName As String, ByRef DevType As String, ByRef Val As Double, ByRef StrUpd As String)
        Dim Device As String = IFACE_NAME & "-" & TStatName & DevType
        Dim DeviceRef As Integer = hs.DeviceExistsAddress(Device, False)

        If DeviceRef = -1 Then
            DeviceRef = CreateMissingDevice(TStatName, DevType) ' Device does not exist, create device
        End If

        If DeviceRef <> -1 Then
            If hs.DeviceValue(DeviceRef) <> Val Then
                hs.SetDeviceLastChange(DeviceRef, Now())
            End If
            hs.SetDeviceValueByRef(DeviceRef, Val, True)
            hs.SetDeviceString(DeviceRef, StrUpd, True)
            WriteLog(DebugLog, "Device: " & Device & " updated", 5)
            Device = IFACE_NAME & "-" & TStatName & _ROOT
            DeviceRef = hs.DeviceExistsAddress(Device, False)
            If hs.DeviceValue(DeviceRef) = -2 Then hs.SetDeviceValueByRef(DeviceRef, 0, False)
        Else
            WriteLog(DebugLog, "Can't update Device: " & Device & " as this device does not exist", 5)
        End If
    End Sub
#End Region

#Region "TCP/IP Procedures"
    Private Sub AnalyseIncomingData(ByRef TStatName As String, ByRef TCPIncomingMessage As String, ByRef Command As String, ByRef Value As String)
        Try

            WriteLog(DebugLog, "In AnalyseIncomingData", 5)
            WriteLog(DebugLog, "We got data: " & TCPIncomingMessage, 5)

            Dim jss = New JavaScriptSerializer()
            Dim data = jss.Deserialize(Of Object)(TCPIncomingMessage)

            For Each MasterKey In data
                Select Case MasterKey.key
                    Case "devices" ' Handle results like INFO commands
                        Console.WriteLine("Number of devices: " & data.count)
                        Dim parts As Object = MasterKey.value

                        Console.WriteLine("Subkeys: " & parts(0).count)
                        For Each Subkey In parts(0)
                            Select Case Subkey.key
                                Case "CURRENT_TEMPERATURE"
                                    UpdateHSDeviceValue(TStatName, _TEMPERATURE, Val(Subkey.value))
                                Case "CURRENT_SET_TEMPERATURE"
                                    UpdateHSDeviceValue(TStatName, _SETPOINT, Val(Subkey.value))
                                Case "AWAY"
                                    If CBool(Subkey.value) Then
                                        UpdateHSDeviceValue(TStatName, _AWAY, 1)
                                    Else
                                        UpdateHSDeviceValue(TStatName, _AWAY, 0)
                                    End If
                                Case "STANDBY"
                                    If CBool(Subkey.value) Then
                                        UpdateHSDeviceValue(TStatName, _STANDBY, 1)
                                    Else
                                        UpdateHSDeviceValue(TStatName, _STANDBY, 0)
                                    End If
                                Case "LOCK"
                                    If CBool(Subkey.value) Then
                                        UpdateHSDeviceString(TStatName, _LOCK, 1, "Locked")
                                    Else
                                        UpdateHSDeviceString(TStatName, _LOCK, -2, "Unlocked")
                                    End If
                                Case "HOLD_TIME"
                                    Dim TimeLeft As String = Subkey.value
                                    Dim TimeLeftHours As String = Left(TimeLeft, InStr(TimeLeft, ":") - 1)
                                    Dim TimeLeftMins As String = Right(TimeLeft, Len(TimeLeft) - InStr(TimeLeft, ":"))
                                    Dim TimeLeftTotal As Integer = Val(TimeLeftHours) * 60 + Val(TimeLeftMins)
                                    Dim TimeLeftString As String = Format(TimeLeftHours, "00") & ":" & Format(TimeLeftMins, "00")
                                    If TimeLeftTotal = 0 Then
                                        UpdateHSDeviceString(TStatName, _HOLD, 0, "OFF")
                                    Else
                                        UpdateHSDeviceValue(TStatName, _HOLD, TimeLeftTotal) ' NEW
                                        UpdateHSDeviceString(TStatName, _HOLD, TimeLeftTotal, TimeLeftString)
                                    End If
                                Case Else
                                    '  Console.WriteLine(Subkey.key)
                            End Select
                        Next
                    Case "result"
                        Select Case MasterKey.value
                            Case "away on"
                                UpdateHSDeviceValue(TStatName, _AWAY, 1)
                            Case "away off"
                                UpdateHSDeviceValue(TStatName, _AWAY, 0)
                            Case "frost on"
                                UpdateHSDeviceValue(TStatName, _STANDBY, 1)
                            Case "frost off"
                                UpdateHSDeviceValue(TStatName, _STANDBY, 0)
                            Case "temperature was set" ' Now use the passed value parameter to update HS
                                UpdateHSDeviceValue(TStatName, _SETPOINT, Value)
                            Case "locked"
                                UpdateHSDeviceString(TStatName, _LOCK, 1, "Locked")
                            Case "unlocked"
                                UpdateHSDeviceString(TStatName, _LOCK, -2, "Unlocked")
                            Case "timer hold on"
                                If Val(Value) = 0 Then
                                    UpdateHSDeviceString(TStatName, _HOLD, 0, "OFF")
                                Else
                                    Dim HoldHours As Integer = Val(Value) \ 60
                                    Dim HoldMinutes As Integer = Val(Value) - (HoldHours * 60)
                                    Dim HoldLeft As String = Format(HoldHours, "00") & ":" & Format(HoldMinutes, "00")
                                    UpdateHSDeviceString(TStatName, _HOLD, Val(Value), HoldLeft)
                                End If

                            Case "timer hold off"
                                UpdateHSDeviceString(TStatName, _HOLD, 0, "OFF")
                            Case Else
                                Console.WriteLine("Invalid/Unhandled Value: " & MasterKey.value)
                        End Select
                    Case "firmware version"
                        _NeoFirmware = MasterKey.value
                    Case "error"
                        ' This was an error, now update the string
                        UpdateHSDeviceString(TStatName, _ROOT, -2, "Last error: " & MasterKey.value)
                    Case Else
                        ' This might be a command like Comfort Levels where the Masterkey is the name of the device
                        Select Case Command

                            Case Else
                                Console.WriteLine("Invalid/Unhandled Key: " & MasterKey.key)
                                UpdateHSDeviceString(TStatName, _ROOT, -2, "Last error: " & MasterKey.value)
                        End Select
                End Select
            Next

        Catch ex As Exception
            WriteLog(ErrorLog, "Exception from izReadCallBack: " & ex.Message, 1)
        End Try
    End Sub
    Sub SendAndReceiveTCP(ByRef Index As String, Message As String, ByRef Command As String, Optional ByRef Value As Integer = -1000)
        Try
            Console.WriteLine("SendAndReceive command: " & Message)
            Dim port As Int32 = _TCPPort
            Dim server As String = _IPAddress
            Dim client As New TcpClient(server, port)

            ' Translate the passed message into ASCII and store it as a Byte array. 
            Dim data As [Byte]() = StrToByteArray(Message, True)

            ' Get a client stream for reading and writing. 
            Dim stream As NetworkStream = client.GetStream()

            stream.ReadTimeout = 2000
            stream.WriteTimeout = 2000

            ' Send the message to the connected TcpServer. 
            stream.Write(data, 0, data.Length)

            ' Receive the TcpServer.response. 
            ' Buffer to store the response bytes.
            data = New [Byte](65536) {}

            ' String to store the response ASCII representation. 
            Dim responseData As [String] = [String].Empty

            ' Read the first batch of the TcpServer response bytes. 
            Dim bytes As Int32 = stream.Read(data, 0, data.Length)
            ReDim Preserve data(bytes - 1)
            responseData = BytesToString(data)

            AnalyseIncomingData(Index, responseData, Command, Value)

            ' Close everything.
            stream.Close()
            client.Close()

            If Index <> "0" Then UpdateHSDeviceString(Index, _ROOT, 0, "")
        Catch e As ArgumentNullException
            Console.WriteLine("ArgumentNullException: {0}", e)
            WriteLog(ErrorLog, "ArgumentNullException: " & e.ToString, 0)
            UpdateHSDeviceString(Index, _ROOT, -1002, "Problems communicating with NEO Hub")
        Catch e As SocketException
            Console.WriteLine("SocketException: {0}", e)
            WriteLog(ErrorLog, "TCP Connection Error: " & e.ToString, 0)
            UpdateHSDeviceString(Index, _ROOT, -1002, "Problems communicating with NEO Hub")
        Catch e As Exception
            Console.WriteLine("Error: {0}", e)
            ' WriteLog(ErrorLog, "TCP Connection Error: " & e.ToString, 0)
            UpdateHSDeviceValue(Index, _ROOT, -1002)
        End Try
    End Sub
#End Region ' TCP/IP Procedures

#Region "WebPage Stuff"
    Friend Function ConfigPostHeader(ByVal Title As String) As String
        Dim stb As New StringBuilder

        stb.Append("<form id='frmNEO' name='NEOTab' method='Post'>")
        stb.Append(" <table border='0' cellpadding='0' cellspacing='0' width='610'>")

        stb.Append("<tr><td colspan='4' align='Left' style='font-size:12pt; height:30px;' nowrap><b>" & Title & "</b></td></tr>")

        stb.Append("<table border='0' cellpadding='1' cellspacing='0'>")
        'stb.Append("<tr>")
        'stb.Append("<td class='tablecolumn' width='300'>Option:</td>")
        'stb.Append("<td class='tablecolumn' width='50'>Setting:</td>")
        'stb.Append("</tr>")

        Return stb.ToString
    End Function
    Friend Function ConfigPostFooter() As String
        Dim stb As New StringBuilder

        stb.Append("</table>")
        stb.Append("<br>")
        stb.Append("<b><font color='red'>Warning: deselecting an option will case the plug-in to delete the relevant Child devices</b>")
        stb.Append("<br><br>")
        Dim bSave As New clsJQuery.jqButton("Save", "Save", "DeviceUtility", True)
        stb.Append(bSave.Build)
        bSave = New clsJQuery.jqButton("Cancel", "Cancel", "DeviceUtility", True)
        stb.Append(bSave.Build)

        stb.Append("</form>")
        Return stb.ToString
    End Function
    Friend Function BuildSingleConfigSelector(ByVal Question As String, ByVal Name As String, ByVal Selected As Boolean) As String
        Dim stb As New StringBuilder
        stb.Append("<tr>")

        stb.Append("<td>" & Question & "</td>")

        stb.Append("<td>")
        Dim cb As New clsJQuery.jqCheckBox(Name, "", "", False, False)
        cb.id = "o" & Name
        cb.checked = Selected
        cb.sliderStyle = True

        stb.Append(cb.Build)
        stb.Append("</td>")

        stb.Append("</tr>")
        Return stb.ToString
    End Function
    Friend Function ExtractConfigOptions(ByVal CurrentRef As Integer, ByVal Data As String, Optional ByVal Name As String = "") As clsRootConfigOptions
        Dim parts As Collections.Specialized.NameValueCollection
        Dim CfgOptions As New clsRootConfigOptions(Name)

        parts = HttpUtility.ParseQueryString(Data)

        ' Assume all options are un-ticked
        For Each key In parts.AllKeys
            Select Case key
                Case "Battery"
                    CfgOptions.AirDevice = True
                Case "FloorTemp"
                    CfgOptions.UseFloorTempSensor = True
                Case "AirTemp"
                    CfgOptions.UseAirTempSensor = True
            End Select
        Next

        Return CfgOptions
    End Function
    Friend Function PullPEDData(ByVal dvRef As Integer) As clsRootConfigOptions 'Object
        Try
            Dim dv As Scheduler.Classes.DeviceClass = Nothing
            dv = hs.GetDeviceByRef(dvRef)

            Dim DeviceType As String = dv.Device_Type_String(Nothing)
            DeviceType = Right(DeviceType, DeviceType.Length - IFACE_NAME.Length)

            Dim PED As clsPlugExtraData = dv.PlugExtraData_Get(hs)
            If PED Is Nothing Then Return Nothing

            Dim RCOptions As New clsRootConfigOptions
            RCOptions = PEDGet(PED, PEDName)
            Return RCOptions
        Catch
            WriteLog(ErrorLog, Err.Description, 0)
            Return Nothing
        End Try
    End Function
    Friend Function ListAllThermostats() As List(Of clsRootConfigOptions)
        Dim CompleteList As New List(Of clsRootConfigOptions)

        Try
            Dim dv As Scheduler.Classes.DeviceClass
            Dim EN As Scheduler.Classes.clsDeviceEnumeration
            EN = hs.GetDeviceEnumerator
            If EN Is Nothing Then
                WriteLog(ErrorLog, "Error getting Enumerator", 0)
                Return Nothing
            End If
            Do
                dv = EN.GetNext
                If dv Is Nothing Then Continue Do
                If dv.Interface(Nothing) = IFACE_NAME Then ' One of ours
                    Dim DeviceType As String = dv.Device_Type_String(Nothing)
                    DeviceType = Right(DeviceType, DeviceType.Length - IFACE_NAME.Length)
                    If InStr(DeviceType.ToLower, "root") > 0 Then
                        Dim dvRef As Integer = dv.Ref(Nothing)
                        Dim RCOptions As New clsRootConfigOptions
                        Try ' Try is needed 
                            RCOptions = PullPEDData(dv.Ref(Nothing))
                            If RCOptions IsNot Nothing Then CompleteList.Add(RCOptions)
                        Catch ex As Exception

                        End Try
                    End If
                End If
            Loop Until EN.Finished
        Catch ex As Exception
            hs.WriteLog("Error", "Exception in device enumeration: " & ex.Message)
            Return Nothing
        End Try

        CompleteList.Sort(Function(x, y) x.ThermostatName.CompareTo(y.ThermostatName))
        Return CompleteList

    End Function
#End Region
End Module
